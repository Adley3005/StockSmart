import React from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Settings, Sparkles, X, Check, Store, ShieldCheck, UserCheck } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'settings' | 'plans';
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, initialTab = 'settings' }) => {
  const { shift, cashier, toggleShift, showToast } = useBodega();
  const [activeSubTab, setActiveSubTab] = React.useState<'settings' | 'plans'>(initialTab);

  React.useEffect(() => {
    setActiveSubTab(initialTab);
  }, [initialTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none">
      <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold">
              {activeSubTab === 'plans' ? <Sparkles className="w-5 h-5 text-amber-400" /> : <Settings className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                {activeSubTab === 'plans' ? 'Planes para Bodegas' : 'Ajustes del Negocio'}
              </h3>
              <p className="text-xs text-slate-500">Minimarket Don Pepe · Lima, Perú</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-bold">
          <button
            onClick={() => setActiveSubTab('settings')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              activeSubTab === 'settings' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Ajustes de Bodega
          </button>
          <button
            onClick={() => setActiveSubTab('plans')}
            className={`flex-1 py-1.5 rounded-lg transition ${
              activeSubTab === 'plans' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Planes & Suscripción
          </button>
        </div>

        {activeSubTab === 'settings' ? (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
              <span className="font-bold text-slate-500 uppercase tracking-wide text-[10px]">Negocio</span>
              <p className="text-sm font-black text-slate-900">Minimarket Don Pepe</p>
              <p className="text-slate-600">RUC: 10452389101 · Los Olivos, Lima</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-900">Turno y Cajero Actual</p>
                <p className="text-slate-500 mt-0.5">Atiende: <strong>{cashier}</strong> (Turno {shift})</p>
              </div>

              <button
                onClick={toggleShift}
                className="px-3 py-1.5 bg-slate-900 text-white font-bold rounded-xl active:scale-95 transition"
              >
                Alternar
              </button>
            </div>

            <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-950 space-y-1">
              <p className="font-extrabold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Base de Datos Offline-First</span>
              </p>
              <p className="text-slate-600 text-[11px]">
                Tu información se almacena de forma segura en la memoria de este celular. No necesitas wifi para seguir cobrando en la bodega.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3 text-xs">
            {/* Bodega Pro active */}
            <div className="p-4 rounded-2xl border-2 border-emerald-500 bg-emerald-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                  PLAN ACTUAL
                </span>
                <span className="font-mono font-black text-sm text-emerald-900">S/ 39 / mes</span>
              </div>
              <h4 className="text-sm font-black text-slate-900">Bodega Pro (Ilimitado)</h4>
              <ul className="space-y-1 text-slate-700 text-[11px]">
                <li className="flex items-center gap-1.5">✓ Cuaderno de fiados con avisos por WhatsApp</li>
                <li className="flex items-center gap-1.5">✓ Modo sin internet para cuando se corta la señal</li>
                <li className="flex items-center gap-1.5">✓ Alertas automáticas de vencimiento a 7 días</li>
                <li className="flex items-center gap-1.5">✓ Soporte en español por WhatsApp</li>
              </ul>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="min-h-[44px] px-5 bg-slate-900 text-white font-black text-xs rounded-xl"
          >
            Listo
          </button>
        </div>

      </div>
    </div>
  );
};
