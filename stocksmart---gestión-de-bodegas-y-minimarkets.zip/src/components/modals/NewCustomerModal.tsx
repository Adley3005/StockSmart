import React, { useState } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { UserPlus, X, Check } from 'lucide-react';

interface NewCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewCustomerModal: React.FC<NewCustomerModalProps> = ({ isOpen, onClose }) => {
  const { addCustomer } = useBodega();

  const [name, setName] = useState('');
  const [reference, setReference] = useState('');
  const [phone, setPhone] = useState('');
  const [creditLimit, setCreditLimit] = useState<number>(100);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      addCustomer(
        name.trim(),
        reference.trim() || 'Vecino de la zona',
        phone.trim() || '999000111',
        creditLimit || 100
      );
      setName('');
      setReference('');
      setPhone('');
      setCreditLimit(100);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none">
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Anotar Vecino en Cuaderno
              </h3>
              <p className="text-[11px] text-slate-500">Abrir cuenta de fiado con tope</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Nombre o apodo del vecino:
            </label>
            <input
              type="text"
              placeholder="Ej. Sra. Juana de la esquina"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full p-2.5 font-bold border rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Referencia de casa / barrio:
            </label>
            <input
              type="text"
              placeholder="Ej. Frente a la posta médica, Mz C"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="w-full p-2.5 border rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Celular (para recordatorios WhatsApp):
            </label>
            <input
              type="tel"
              placeholder="Ej. 987654321"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full p-2.5 font-mono border rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Tope máximo sugerido de fiado (S/):
            </label>
            <input
              type="number"
              step="10"
              value={creditLimit}
              onChange={(e) => setCreditLimit(parseFloat(e.target.value) || 0)}
              className="w-full p-2.5 font-mono font-bold text-center border rounded-xl"
            />
            <p className="text-[11px] text-slate-500 mt-0.5">
              Si supera este monto, el sistema avisará en rojo para no fiar más.
            </p>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              type="submit"
              className="min-h-[44px] bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
            >
              <Check className="w-4 h-4" />
              <span>Guardar en Libreta</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
            >
              Cancelar
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
