import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { ProductCategory } from '../../types';
import { ClipboardCheck, Check, X, ArrowRight, ArrowLeft } from 'lucide-react';
import { formatUnitPlural } from '../../utils/helpers';

interface StockCountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StockCountModal: React.FC<StockCountModalProps> = ({ isOpen, onClose }) => {
  const { products, adjustStockCount } = useBodega();

  const categories: ProductCategory[] = ['Abarrotes', 'Lácteos', 'Bebidas', 'Snacks', 'Limpieza'];

  const [currentCategoryIndex, setCurrentCategoryIndex] = useState<number>(0);
  const [isReviewStep, setIsReviewStep] = useState<boolean>(false);

  // Store user-entered counts only for touched/modified items
  const [touchedCounts, setTouchedCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    // Reset state whenever modal is opened
    if (isOpen) {
      setCurrentCategoryIndex(0);
      setIsReviewStep(false);
      setTouchedCounts({});
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentCategory = categories[currentCategoryIndex];
  const categoryProducts = products.filter(p => p.category === currentCategory);

  const handleCountChange = (productId: string, val: number) => {
    setTouchedCounts(prev => ({
      ...prev,
      [productId]: Math.max(0, val)
    }));
  };

  // Differences calculation: ONLY for items touched by Don Pepe where physicalCount !== system stock
  const differences = Object.entries(touchedCounts)
    .map(([productId, physicalCount]) => {
      const product = products.find(p => p.id === productId);
      if (!product) return null;
      const countNum = Number(physicalCount);
      const diff = countNum - product.stock;
      return {
        product,
        systemStock: product.stock,
        physicalCount: countNum,
        diff
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null && item.diff !== 0);

  const handleNextCategory = () => {
    if (currentCategoryIndex < categories.length - 1) {
      setCurrentCategoryIndex(currentCategoryIndex + 1);
    } else {
      setIsReviewStep(true);
    }
  };

  const handlePrevCategory = () => {
    if (isReviewStep) {
      setIsReviewStep(false);
    } else if (currentCategoryIndex > 0) {
      setCurrentCategoryIndex(currentCategoryIndex - 1);
    }
  };

  const handleConfirmAdjust = () => {
    const adjustments = Object.entries(touchedCounts)
      .map(([productId, physicalCount]) => ({ productId, physicalCount }))
      .filter(adj => {
        const prod = products.find(p => p.id === adj.productId);
        return prod && prod.stock !== adj.physicalCount;
      });

    adjustStockCount(adjustments);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-xl w-full p-4 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-emerald-400 flex items-center justify-center font-bold">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Contar Stock Físico (Guiado)
              </h3>
              <p className="text-xs text-slate-500">
                {isReviewStep ? 'Paso final: Resumen de diferencias' : `Paso ${currentCategoryIndex + 1} de 5: Pasillo de ${currentCategory}`}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-600" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Dots */}
        <div className="py-2.5 flex items-center justify-between gap-1 text-xs">
          {categories.map((cat, idx) => (
            <div
              key={cat}
              className={`flex-1 text-center py-1.5 rounded-lg font-bold text-[11px] truncate transition ${
                !isReviewStep && currentCategoryIndex === idx
                  ? 'bg-emerald-600 text-white'
                  : idx < currentCategoryIndex || isReviewStep
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-slate-100 text-slate-400'
              }`}
            >
              {cat}
            </div>
          ))}
          <div
            className={`flex-1 text-center py-1.5 rounded-lg font-bold text-[11px] truncate transition ${
              isReviewStep ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-400'
            }`}
          >
            Resumen
          </div>
        </div>

        {/* Modal Body */}
        <div className="my-3 overflow-y-auto flex-1 space-y-2 pr-1">
          {!isReviewStep ? (
            <div className="space-y-2">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs text-slate-600">
                <p className="font-bold text-slate-800">
                  Estás en: {currentCategory} ({categoryProducts.length} productos)
                </p>
                <p className="text-[11px] mt-0.5">
                  Modifica solo si la cantidad física en la estantería difiere del sistema.
                </p>
              </div>

              {categoryProducts.map((p) => {
                const isTouched = touchedCounts[p.id] !== undefined;
                const currentPhysical = isTouched ? touchedCounts[p.id] : p.stock;
                const diff = currentPhysical - p.stock;

                return (
                  <div
                    key={p.id}
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-2 shadow-xs transition ${
                      isTouched ? 'bg-emerald-50/40 border-emerald-300' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex-1 truncate">
                      <p className="text-xs font-bold text-slate-900 truncate">{p.name}</p>
                      <p className="text-[11px] text-slate-500">
                        Sistema: <strong className="font-mono text-slate-800">{formatUnitPlural(p.stock, p.unit)}</strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleCountChange(p.id, currentPhysical - 1)}
                          className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center text-base active:scale-95 cursor-pointer"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="0"
                          value={currentPhysical}
                          onChange={(e) => handleCountChange(p.id, parseInt(e.target.value) || 0)}
                          className="w-16 h-10 text-center font-mono font-black text-sm rounded-xl border border-slate-300"
                        />
                        <button
                          type="button"
                          onClick={() => handleCountChange(p.id, currentPhysical + 1)}
                          className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center text-base active:scale-95 cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      {diff !== 0 && (
                        <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${
                          diff > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {diff > 0 ? `+${diff}` : diff}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Review Differences Step */
            <div className="space-y-3">
              <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-1">
                <p className="text-sm font-black text-white">
                  Resumen de Ajustes Físicos
                </p>
                <p className="text-xs text-slate-300">
                  {differences.length === 0
                    ? 'No modificaste ningún producto; tu inventario coincide con el sistema.'
                    : `Se ajustarán ${differences.length} productos con discrepancias físicas.`}
                </p>
              </div>

              {differences.length > 0 ? (
                <div className="space-y-2">
                  {differences.map(({ product, systemStock, physicalCount, diff }) => (
                    <div
                      key={product.id}
                      className="p-3 rounded-2xl bg-white border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-bold text-slate-900">{product.name}</p>
                        <p className="text-slate-500 font-mono">
                          Sistema: {systemStock} → Conteo real: {physicalCount} {product.unit}
                        </p>
                      </div>

                      <span className={`px-2.5 py-1 rounded-xl font-black font-mono ${
                        diff > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {diff > 0 ? `+${diff} sobrante` : `${diff} faltante`}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-emerald-700 bg-emerald-50 rounded-2xl border border-emerald-200">
                  <Check className="w-10 h-10 mx-auto text-emerald-600 mb-2" />
                  <p className="font-bold">Sin diferencias registradas</p>
                  <p className="text-xs mt-1 text-slate-600">No se alterará ninguna venta ni stock del día.</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <button
            onClick={handlePrevCategory}
            disabled={currentCategoryIndex === 0 && !isReviewStep}
            className="min-h-[46px] px-4 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs flex items-center gap-1 disabled:opacity-40"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Atrás</span>
          </button>

          {!isReviewStep ? (
            <button
              onClick={handleNextCategory}
              className="min-h-[46px] px-5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition"
            >
              <span>{currentCategoryIndex === categories.length - 1 ? 'Revisar Diferencias' : 'Siguiente Pasillo'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleConfirmAdjust}
              className="min-h-[46px] px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl flex items-center gap-2 shadow-md transition"
            >
              <Check className="w-4 h-4" />
              <span>CONFIRMAR AJUSTES DE STOCK</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
