import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product } from '../../types';
import { ScanBarcode, Camera, X, Check, ShoppingCart } from 'lucide-react';
import { formatCurrency } from '../../utils/helpers';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({ isOpen, onClose }) => {
  const { products, addToCart, showToast } = useBodega();
  const [detectedProduct, setDetectedProduct] = useState<Product | null>(null);
  const [isScanning, setIsScanning] = useState(true);

  // Auto simulate scan after 1.5s
  useEffect(() => {
    if (isOpen) {
      setIsScanning(true);
      setDetectedProduct(null);
      
      // Pick a common scanned item, e.g. Inka Kola 500ml or Leche Gloria
      const targetProd = products.find(p => p.id === 'prod-23') || products[0];

      const timer = setTimeout(() => {
        setDetectedProduct(targetProd);
        setIsScanning(false);
      }, 1400);

      return () => clearTimeout(timer);
    }
  }, [isOpen, products]);

  if (!isOpen) return null;

  const handleAddAndClose = () => {
    if (detectedProduct) {
      addToCart(detectedProduct, 1);
      showToast(`Escaneado: +1 ${detectedProduct.name} al ticket`, 'success');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-5 text-white text-center shadow-2xl relative space-y-4">
        
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-center gap-2">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Camera className="w-5 h-5" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-black text-white">Escáner de Código de Barras</h3>
            <p className="text-[11px] text-slate-400">Cámara rápida para mostrador</p>
          </div>
        </div>

        {/* Viewfinder simulator with laser sweep */}
        <div className="relative h-48 w-full bg-slate-950 rounded-2xl border-2 border-emerald-500/60 overflow-hidden flex flex-col items-center justify-center p-3">
          {/* Laser animation line */}
          <div className="absolute left-2 right-2 h-0.5 bg-gradient-to-r from-red-500 via-emerald-400 to-red-500 shadow-[0_0_12px_#10b981] animate-laser pointer-events-none" />

          {/* Barcode artwork */}
          <div className="opacity-70 font-mono text-2xl tracking-widest text-slate-300 font-bold select-none">
            |||| | | ||| |||| |
          </div>

          <div className="mt-4 text-xs font-mono text-emerald-400">
            {isScanning ? (
              <span className="flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Leyendo código EAN-13...
              </span>
            ) : detectedProduct ? (
              <span className="text-emerald-300 font-bold">
                ✓ ¡Código reconocido! ({detectedProduct.barcode})
              </span>
            ) : null}
          </div>
        </div>

        {/* Detected Product Result */}
        {detectedProduct && (
          <div className="bg-slate-800 p-3.5 rounded-2xl border border-slate-700 text-left space-y-1">
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wide">
              Producto Reconocido
            </span>
            <p className="text-sm font-black text-white">{detectedProduct.name}</p>
            <div className="flex justify-between items-baseline pt-1">
              <span className="text-xs text-slate-400 font-mono">Stock actual: {detectedProduct.stock} {detectedProduct.unit}s</span>
              <span className="text-base font-black font-mono text-emerald-400">{formatCurrency(detectedProduct.price)}</span>
            </div>
          </div>
        )}

        {/* Buttons */}
        <div className="space-y-2 pt-1">
          {detectedProduct ? (
            <button
              onClick={handleAddAndClose}
              className="w-full min-h-[46px] bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg transition"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>AGREGAR AL TICKET Y CONTINUAR</span>
            </button>
          ) : (
            <p className="text-xs text-slate-400 animate-pulse">
              Apunta la cámara al empaque...
            </p>
          )}

          <button
            onClick={onClose}
            className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl"
          >
            Cerrar escáner
          </button>
        </div>

      </div>
    </div>
  );
};
