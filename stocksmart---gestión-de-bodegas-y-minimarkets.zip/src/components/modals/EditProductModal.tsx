import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product } from '../../types';
import { Edit3, X, Check } from 'lucide-react';

interface EditProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EditProductModal: React.FC<EditProductModalProps> = ({ product, isOpen, onClose }) => {
  const { editProduct } = useBodega();

  const [price, setPrice] = useState<number>(0);
  const [cost, setCost] = useState<number>(0);
  const [minStock, setMinStock] = useState<number>(5);
  const [expiryDate, setExpiryDate] = useState<string>('');

  useEffect(() => {
    if (product) {
      setPrice(product.price);
      setCost(product.cost);
      setMinStock(product.minStock);
      setExpiryDate(product.expiryDate || '');
    }
  }, [product]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const handleSave = () => {
    editProduct(product.id, {
      price,
      cost,
      minStock,
      expiryDate
    });
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Editar Producto
              </h3>
              <p className="text-[11px] text-slate-500">Ajustar precio, costo y mínimos</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-2 rounded-xl" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Producto:</label>
            <p className="font-extrabold text-slate-900 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              {product.name}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Precio Venta (S/):</label>
              <input
                type="number"
                step="0.10"
                min="0"
                value={price}
                onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
                className="w-full p-2.5 font-mono font-black border border-slate-300 rounded-xl focus:border-emerald-600 outline-none text-sm"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Costo Proveedor (S/):</label>
              <input
                type="number"
                step="0.10"
                min="0"
                value={cost}
                onChange={(e) => setCost(parseFloat(e.target.value) || 0)}
                className="w-full p-2.5 font-mono font-black border border-slate-300 rounded-xl focus:border-emerald-600 outline-none text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Stock Mínimo ({product.unit}s):</label>
              <input
                type="number"
                min="1"
                value={minStock}
                onChange={(e) => setMinStock(parseInt(e.target.value) || 1)}
                className="w-full p-2.5 font-mono font-bold border border-slate-300 rounded-xl focus:border-emerald-600 outline-none text-sm"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Fecha Vencimiento:</label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full p-2 text-xs font-mono font-bold border border-slate-300 rounded-xl focus:border-emerald-600 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={handleSave}
            className="min-h-[46px] bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
          >
            <Check className="w-4 h-4" />
            <span>Guardar Cambios</span>
          </button>
          <button
            onClick={onClose}
            className="min-h-[46px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Cancelar
          </button>
        </div>

      </div>
    </div>
  );
};
