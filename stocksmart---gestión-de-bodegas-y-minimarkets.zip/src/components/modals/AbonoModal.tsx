import React, { useState, useEffect } from 'react';
import { PaymentMethod } from '../../types';
import { useBodega } from '../../context/BodegaContext';
import { Coins, X, Check, Banknote, Smartphone } from 'lucide-react';
import { formatCurrency } from '../../utils/helpers';

interface AbonoModalProps {
  customerId: string | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AbonoModal: React.FC<AbonoModalProps> = ({ customerId, isOpen, onClose }) => {
  const { customers, registerAbono } = useBodega();
  const customer = customers.find(c => c.id === customerId);

  const [amount, setAmount] = useState<string>('');
  const [method, setMethod] = useState<PaymentMethod>('Efectivo');
  const [vueltoNotice, setVueltoNotice] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount('');
      setMethod('Efectivo');
      setVueltoNotice(null);
    }
  }, [isOpen, customerId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !customer) return null;

  const numAmount = parseFloat(amount) || 0;
  const changeDue = Math.max(0, numAmount - customer.balance);
  const remaining = Math.max(0, customer.balance - numAmount);

  const handleConfirm = () => {
    if (numAmount > 0) {
      const result = registerAbono(customer.id, numAmount, method);
      if (result.changeDue > 0) {
        setVueltoNotice(result.changeDue);
      } else {
        onClose();
      }
    }
  };

  const handleQuickAmount = (val: number) => {
    setAmount(val.toFixed(2));
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200 animate-slide-up">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Registrar Abono
              </h3>
              <p className="text-[11px] text-slate-500">Pago a cuenta en el cuaderno</p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-600" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customer & current debt */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs space-y-1">
          <p className="font-extrabold text-slate-900 text-sm">{customer.name}</p>
          <div className="flex justify-between items-baseline pt-1">
            <span className="text-slate-600">Deuda actual en libreta:</span>
            <span className="text-base font-black font-mono text-slate-900">{formatCurrency(customer.balance)}</span>
          </div>
        </div>

        {/* Notice if change is due */}
        {vueltoNotice !== null ? (
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-300 text-center space-y-2">
            <p className="text-xs font-black text-emerald-950">¡Deuda cancelada en su totalidad!</p>
            <p className="text-xs text-slate-700">Vuelto a entregar al vecino:</p>
            <p className="text-2xl font-black font-mono text-emerald-700">{formatCurrency(vueltoNotice)}</p>
            <button
              onClick={onClose}
              className="w-full mt-2 py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl"
            >
              Cerrar y continuar
            </button>
          </div>
        ) : (
          <>
            {/* Amount Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">
                Monto que entrega el vecino (S/):
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">S/</span>
                <input
                  type="number"
                  step="0.5"
                  placeholder="0.00"
                  autoFocus
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-9 pr-3 py-3 text-center font-mono font-black text-xl rounded-2xl border-2 border-slate-300 focus:border-emerald-600 outline-none"
                />
              </div>

              {/* Quick buttons */}
              <div className="grid grid-cols-4 gap-1.5 pt-1 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => handleQuickAmount(10)}
                  className="min-h-[42px] bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  S/ 10
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickAmount(20)}
                  className="min-h-[42px] bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  S/ 20
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickAmount(50)}
                  className="min-h-[42px] bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  S/ 50
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickAmount(customer.balance)}
                  className="min-h-[42px] bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl truncate"
                  title="Pagar la deuda total"
                >
                  Total
                </button>
              </div>
            </div>

            {/* Method */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">
                Medio de pago:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'Efectivo', label: 'Efectivo', icon: Banknote },
                  { id: 'Yape', label: 'Yape', icon: Smartphone },
                  { id: 'Plin', label: 'Plin', icon: Smartphone }
                ].map((m) => {
                  const Icon = m.icon;
                  const isSel = method === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setMethod(m.id as PaymentMethod)}
                      className={`min-h-[44px] p-2 rounded-xl text-xs font-bold border-2 flex items-center justify-center gap-1.5 transition ${
                        isSel ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-black' : 'border-slate-200 bg-white text-slate-700'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{m.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Change or remaining summary */}
            <div className="p-3 bg-slate-50 rounded-xl text-xs flex justify-between font-bold text-slate-700 items-baseline">
              {changeDue > 0 ? (
                <>
                  <span className="text-emerald-800 font-extrabold">Vuelto a devolver:</span>
                  <span className="font-mono text-emerald-700 text-base font-black">{formatCurrency(changeDue)}</span>
                </>
              ) : (
                <>
                  <span>Nuevo saldo tras abono:</span>
                  <span className="font-mono text-emerald-700 text-sm font-black">{formatCurrency(remaining)}</span>
                </>
              )}
            </div>

            {/* Confirm */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleConfirm}
                disabled={numAmount <= 0}
                className="min-h-[46px] bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
              >
                <Check className="w-4 h-4" />
                <span>Confirmar Abono</span>
              </button>
              <button
                onClick={onClose}
                className="min-h-[46px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancelar
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
