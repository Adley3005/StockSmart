import React, { useState, useMemo } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product, PaymentMethod } from '../../types';
import { 
  Search, 
  ScanBarcode, 
  Plus, 
  Minus, 
  Trash2, 
  RotateCcw, 
  Check, 
  X, 
  Receipt, 
  Banknote, 
  Smartphone, 
  BookMarked,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { formatCurrency, getStockStatus } from '../../utils/helpers';

interface SellViewProps {
  onOpenScanner: () => void;
}

export const SellView: React.FC<SellViewProps> = ({ onOpenScanner }) => {
  const {
    products,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartTotal,
    cartItemsCount,
    processSale,
    undoLastSale,
    canUndoSale,
    undoTimeRemaining,
    lastSaleSummary,
    customers
  } = useBodega();

  // Search and category filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');

  // Bottom sheet / Drawer open state for Mobile
  const [isCheckoutDrawerOpen, setIsCheckoutDrawerOpen] = useState(false);

  // Payment form state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Efectivo');
  const [cashGiven, setCashGiven] = useState<string>('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(customers[0]?.id || '');
  const [isProcessing, setIsProcessing] = useState(false);

  // Quantity modal for long-press / edit
  const [quantityModalProduct, setQuantityModalProduct] = useState<Product | null>(null);
  const [modalQty, setModalQty] = useState<number>(1);

  // Top 8 fast seller products
  const top8Products = useMemo(() => {
    return products.filter((p) => p.isTopSeller).slice(0, 8);
  }, [products]);

  // Filtered products list
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode.includes(searchQuery);
      const matchesCategory =
        selectedCategory === 'todos' || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchQuery, selectedCategory]);

  // Category counts calculated from real stock database
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {
      todos: products.length,
      Bebidas: 0,
      Lácteos: 0,
      Abarrotes: 0,
      Snacks: 0,
      Limpieza: 0
    };
    products.forEach((p) => {
      if (counts[p.category] !== undefined) {
        counts[p.category]++;
      }
    });
    return counts;
  }, [products]);

  const categoryChips = [
    { id: 'todos', label: 'Todos', emoji: '🏪', count: categoryCounts.todos },
    { id: 'Bebidas', label: 'Bebidas', emoji: '🥤', count: categoryCounts.Bebidas },
    { id: 'Lácteos', label: 'Lácteos', emoji: '🥛', count: categoryCounts.Lácteos },
    { id: 'Abarrotes', label: 'Abarrotes', emoji: '🍚', count: categoryCounts.Abarrotes },
    { id: 'Snacks', label: 'Snacks & Galletas', emoji: '🍪', count: categoryCounts.Snacks },
    { id: 'Limpieza', label: 'Limpieza', emoji: '🧼', count: categoryCounts.Limpieza }
  ];

  // Cash change calculation
  const cashGivenNumber = parseFloat(cashGiven) || 0;
  const changeDue = Math.max(0, cashGivenNumber - cartTotal);
  const isExactOrSufficientCash = paymentMethod === 'Efectivo' ? cashGivenNumber >= cartTotal : true;

  // Selected customer for Fiado details
  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);
  const remainingCreditBeforeSale = selectedCustomer ? selectedCustomer.creditLimit - selectedCustomer.balance : 0;
  const willExceedLimit = selectedCustomer ? (selectedCustomer.balance + cartTotal) > selectedCustomer.creditLimit : false;

  // Handler for fast add
  const handleCardClick = (product: Product) => {
    addToCart(product, 1);
  };

  // Handler for custom quantity open
  const handleOpenQuantitySelector = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    const existing = cart.find(ci => ci.product.id === product.id);
    setModalQty(existing ? existing.quantity : 1);
    setQuantityModalProduct(product);
  };

  const handleConfirmCustomQty = () => {
    if (quantityModalProduct) {
      if (modalQty <= 0) {
        removeFromCart(quantityModalProduct.id);
      } else {
        const existing = cart.find(ci => ci.product.id === quantityModalProduct.id);
        if (existing) {
          updateCartQuantity(quantityModalProduct.id, modalQty);
        } else {
          addToCart(quantityModalProduct, modalQty);
        }
      }
      setQuantityModalProduct(null);
    }
  };

  // Quick cash bill / coin click
  const handleAddCash = (amount: number) => {
    setCashGiven(amount.toString());
  };

  const handleProcessSale = async () => {
    if (cart.length === 0 || isProcessing) return;
    setIsProcessing(true);

    try {
      const finalPaid = paymentMethod === 'Efectivo' ? (cashGivenNumber || cartTotal) : cartTotal;
      await processSale(paymentMethod, finalPaid, paymentMethod === 'Fiado' ? selectedCustomerId : undefined);
      setIsCheckoutDrawerOpen(false);
      setCashGiven('');
    } finally {
      setIsProcessing(false);
    }
  };

  // Stock Dot Color
  const getStockDot = (stockStatus: string) => {
    if (stockStatus === 'Agotado') return 'bg-red-600';
    if (stockStatus === 'Bajo') return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  return (
    <div className="relative pb-28 md:pb-6">
      
      {/* ============================================================ */}
      {/* 5-SECOND UNDO BANNER (CONFIRMACIÓN POST-COBRO)               */}
      {/* ============================================================ */}
      {canUndoSale && lastSaleSummary && !lastSaleSummary.isUndo && (
        <div className="mb-4 bg-slate-900 border-2 border-emerald-500 text-white rounded-2xl p-4 shadow-xl flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-extrabold text-white">
                Venta registrada ({lastSaleSummary.ticketNumber} · {formatCurrency(lastSaleSummary.total)})
              </p>
              <p className="text-xs text-slate-300">
                Cobrado con {lastSaleSummary.paymentMethod}. Tienes {undoTimeRemaining}s para deshacer.
              </p>
            </div>
          </div>

          <button
            onClick={undoLastSale}
            className="min-h-[44px] px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs sm:text-sm rounded-xl transition flex items-center gap-1.5 shadow"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Deshacer ({undoTimeRemaining}s)</span>
          </button>
        </div>
      )}

      {/* Main Grid: Products on Left (or full mobile), Cart on Right (Desktop & Tablet) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
        
        {/* ============================================================ */}
        {/* LEFT SECTION: SEARCH, FAST SELLERS & PRODUCT CATALOG        */}
        {/* ============================================================ */}
        <div className="md:col-span-7 xl:col-span-8 space-y-4">
          
          {/* Top Search Bar & Camera Barcode Scanner Simulator */}
          <div className="bg-white p-3.5 sm:p-4 rounded-3xl shadow-sm border border-slate-200 space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar por nombre o código de barras (ej. Gloria, Arroz, Inka Kola)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-9 py-3 bg-slate-50 focus:bg-white text-sm font-medium rounded-2xl border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100 outline-none transition"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                    title="Limpiar búsqueda"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Prominent Barcode Scanner Button */}
              <button
                onClick={onOpenScanner}
                className="min-h-[48px] px-4 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white text-xs sm:text-sm font-extrabold rounded-2xl flex items-center gap-2 shadow-sm transition shrink-0 cursor-pointer"
                title="Escanear con cámara del celular o tablet"
              >
                <ScanBarcode className="w-5 h-5 text-emerald-400" />
                <span className="hidden sm:inline">Escanear</span>
              </button>
            </div>

            {/* Búsqueda por Categoría (Filtros tipo chips para Don Pepe) */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between px-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-black text-slate-800 uppercase tracking-wider">
                    Buscar por Categoría
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">
                    • 1 toque para ver góndola sin escribir
                  </span>
                </div>
                {selectedCategory !== 'todos' && (
                  <button
                    onClick={() => setSelectedCategory('todos')}
                    className="text-xs text-emerald-700 hover:text-emerald-900 font-extrabold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Ver todas ({products.length})</span>
                  </button>
                )}
              </div>

              {/* Chips de Categorías con conteos reales y alta visibilidad */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
                {categoryChips.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`min-h-[48px] px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition-all flex items-center gap-2 border-2 active:scale-95 cursor-pointer shadow-xs ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-300 ring-offset-1'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-white'
                      }`}
                      title={`Filtrar por ${cat.label}`}
                    >
                      <span className="text-lg leading-none">{cat.emoji}</span>
                      <span className="text-xs font-black tracking-tight">{cat.label}</span>
                      <span
                        className={`text-[11px] font-mono font-black px-2 py-0.5 rounded-full ${
                          isSelected
                            ? 'bg-emerald-900 text-white'
                            : 'bg-slate-200/80 text-slate-700'
                        }`}
                      >
                        {cat.count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Banner de Categoría Activa */}
          {selectedCategory !== 'todos' && (
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
              <div className="flex items-center gap-3">
                <span className="text-2xl p-2 bg-emerald-100 rounded-xl">
                  {categoryChips.find((c) => c.id === selectedCategory)?.emoji}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-xs sm:text-sm font-black text-emerald-950">
                      Góndola activa: {selectedCategory}
                    </p>
                    <span className="bg-emerald-200 text-emerald-900 text-[10px] font-mono font-black px-2 py-0.5 rounded-full">
                      {filteredProducts.length} {filteredProducts.length === 1 ? 'producto' : 'productos'}
                    </span>
                  </div>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    {searchQuery 
                      ? `Buscando "${searchQuery}" en ${selectedCategory}` 
                      : 'Toca cualquier producto de esta categoría para sumar al ticket'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                {searchQuery && (
                  <button
                    onClick={() => setSelectedCategory('todos')}
                    className="px-3 py-1.5 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold text-xs transition"
                  >
                    Buscar en toda la tienda
                  </button>
                )}
                <button
                  onClick={() => setSelectedCategory('todos')}
                  className="px-3.5 py-1.5 rounded-xl bg-white text-emerald-950 border border-emerald-300 font-black text-xs shadow-xs hover:bg-emerald-100 transition whitespace-nowrap"
                >
                  Ver todas (48)
                </button>
              </div>
            </div>
          )}

          {/* Grilla de "Más Vendidos" (8 productos) para vender sin buscar */}
          {selectedCategory === 'todos' && !searchQuery && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Más Vendidos (Mostrador Rápido)</span>
                </span>
                <span className="text-[11px] text-slate-500 font-semibold">1 toque = +1</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {top8Products.map((prod) => {
                  const stockStatus = getStockStatus(prod);
                  const inCartQty = cart.find((ci) => ci.product.id === prod.id)?.quantity || 0;
                  return (
                    <div
                      key={prod.id}
                      onClick={() => handleCardClick(prod)}
                      className={`min-h-[86px] bg-white rounded-2xl p-3 border-2 transition-all cursor-pointer relative flex flex-col justify-between active:scale-97 select-none shadow-sm ${
                        inCartQty > 0
                          ? 'border-emerald-500 bg-emerald-50/40 ring-2 ring-emerald-200'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <span className="text-xs font-bold text-slate-900 line-clamp-2 leading-tight">
                          {prod.name}
                        </span>
                        <span 
                          className={`w-2.5 h-2.5 rounded-full shrink-0 mt-0.5 ${getStockDot(stockStatus)}`}
                          title={`Stock: ${prod.stock} (${stockStatus})`}
                        />
                      </div>

                      <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-100">
                        <span className="text-sm font-black text-slate-900 font-mono">
                          {formatCurrency(prod.price)}
                        </span>

                        <div className="flex items-center gap-1">
                          {inCartQty > 0 && (
                            <span className="bg-emerald-600 text-white text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center">
                              {inCartQty}
                            </span>
                          )}
                          <button
                            onClick={(e) => handleOpenQuantitySelector(e, prod)}
                            className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold"
                            title="Ingresar cantidad manual"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Grilla Completa de Productos (Área táctil >= 48px, óptima para alta resolución) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-black text-slate-700 uppercase tracking-wider">
                {selectedCategory === 'todos' ? 'Catálogo Completo' : `Productos de ${selectedCategory}`} ({filteredProducts.length})
              </span>
              <span className="text-[11px] text-slate-500">
                Puntos: <span className="text-emerald-600 font-bold">● OK</span> · <span className="text-amber-600 font-bold">● Bajo</span> · <span className="text-red-600 font-bold">● Agotado</span>
              </span>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 text-center text-slate-400 space-y-2 border border-slate-200">
                <p className="text-sm font-bold text-slate-700">No se encontraron productos</p>
                <p className="text-xs">Prueba seleccionando otra categoría o limpiando el texto de búsqueda.</p>
                <button
                  onClick={() => { setSelectedCategory('todos'); setSearchQuery(''); }}
                  className="mt-2 px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
                >
                  Restablecer filtros
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
                {filteredProducts.map((prod) => {
                  const stockStatus = getStockStatus(prod);
                  const inCartQty = cart.find((ci) => ci.product.id === prod.id)?.quantity || 0;
                  return (
                    <div
                      key={prod.id}
                      onClick={() => handleCardClick(prod)}
                      className={`min-h-[100px] bg-white rounded-2xl p-3 border-2 transition-all cursor-pointer relative flex flex-col justify-between active:scale-97 select-none shadow-sm hover:shadow-md ${
                        inCartQty > 0
                          ? 'border-emerald-500 bg-emerald-50/30 ring-2 ring-emerald-200'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-1.5">
                          <span className="text-xs font-bold text-slate-900 line-clamp-2 leading-tight">
                            {prod.name}
                          </span>
                          <span 
                            className={`w-2.5 h-2.5 rounded-full shrink-0 mt-0.5 ${getStockDot(stockStatus)}`}
                            title={`Stock: ${prod.stock} (${stockStatus})`}
                          />
                        </div>
                        <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                          {prod.stock} {prod.unit}s disponibles
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-100">
                        <span className="text-sm font-black text-slate-900 font-mono">
                          {formatCurrency(prod.price)}
                        </span>

                        <div className="flex items-center gap-1">
                          {inCartQty > 0 && (
                            <span className="bg-emerald-600 text-white text-[11px] font-black px-1.5 py-0.5 rounded-full">
                              {inCartQty}
                            </span>
                          )}
                          <button
                            onClick={(e) => handleOpenQuantitySelector(e, prod)}
                            className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold"
                            title="Cambiar cantidad"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* ============================================================ */}
        {/* RIGHT SECTION: CART & CHECKOUT PANEL (DESKTOP DOCK)          */}
        {/* ============================================================ */}
        <div className="hidden md:block md:col-span-5 xl:col-span-4 sticky top-16">
          <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-slate-900">Cobro de Mostrador</h2>
                  <p className="text-[11px] text-slate-500">{cartItemsCount} productos en ticket</p>
                </div>
              </div>

              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Vaciar</span>
                </button>
              )}
            </div>

            {/* Cart Items List */}
            <div className="max-h-[35vh] overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
              {cart.length === 0 ? (
                <div className="py-10 text-center text-slate-400 space-y-2">
                  <Receipt className="w-10 h-10 mx-auto text-slate-300 stroke-1" />
                  <p className="text-xs font-semibold">Toca un producto para cobrar</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.product.id} className="pt-2 flex items-center justify-between gap-2">
                    <div className="flex-1 truncate">
                      <p className="text-xs font-bold text-slate-900 truncate">
                        {item.product.name}
                      </p>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {formatCurrency(item.product.price)} c/u
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                        className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-bold"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-black font-mono">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => addToCart(item.product, 1)}
                        className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-bold"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="w-16 text-right shrink-0 font-mono text-xs font-black text-slate-900">
                      {formatCurrency(item.product.price * item.quantity)}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Total and Checkout Drawer Form Component */}
            {renderCheckoutForm(
              paymentMethod,
              setPaymentMethod,
              cartTotal,
              cashGiven,
              setCashGiven,
              handleAddCash,
              changeDue,
              selectedCustomerId,
              setSelectedCustomerId,
              customers,
              selectedCustomer,
              remainingCreditBeforeSale,
              willExceedLimit,
              isExactOrSufficientCash,
              handleProcessSale,
              isProcessing,
              cart.length === 0
            )}
          </div>
        </div>

      </div>

      {/* ============================================================ */}
      {/* MOBILE FIXED BOTTOM CART BAR (360-412PX)                     */}
      {/* "N productos · S/ XX.XX · Cobrar" que abre la hoja inferior  */}
      {/* ============================================================ */}
      <div className="md:hidden fixed bottom-16 left-0 right-0 p-3 z-30 pointer-events-none">
        <div className="max-w-md mx-auto pointer-events-auto">
          <button
            onClick={() => setIsCheckoutDrawerOpen(true)}
            disabled={cart.length === 0}
            className={`w-full min-h-[54px] px-5 py-3 rounded-2xl shadow-xl flex items-center justify-between font-black text-sm transition-all active:scale-98 ${
              cart.length > 0
                ? 'bg-emerald-600 text-white shadow-emerald-900/30'
                : 'bg-slate-300 text-slate-600 cursor-not-allowed border border-slate-300'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full font-mono">
                {cartItemsCount} {cartItemsCount === 1 ? 'prod.' : 'prods.'}
              </span>
              <span className="font-mono text-base">
                {formatCurrency(cartTotal)}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span>COBRAR</span>
              <Receipt className="w-4 h-4" />
            </div>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* MOBILE CHECKOUT BOTTOM SHEET (HOJA INFERIOR)                 */}
      {/* ============================================================ */}
      {isCheckoutDrawerOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex flex-col justify-end">
          <div className="bg-white rounded-t-3xl max-h-[88vh] overflow-y-auto p-4 sm:p-5 shadow-2xl space-y-4 animate-slide-up">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-black text-slate-900">Detalle del Cobro</h3>
                <p className="text-xs text-slate-500">{cartItemsCount} productos seleccionados</p>
              </div>
              <button
                onClick={() => setIsCheckoutDrawerOpen(false)}
                className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items in Bottom Sheet */}
            <div className="max-h-44 overflow-y-auto space-y-2 divide-y divide-slate-100 pr-1">
              {cart.map((item) => (
                <div key={item.product.id} className="pt-2 flex items-center justify-between gap-2 text-xs">
                  <div className="flex-1 truncate">
                    <p className="font-bold text-slate-900 truncate">{item.product.name}</p>
                    <p className="text-slate-500 font-mono">{formatCurrency(item.product.price)} c/u</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-bold"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-5 text-center font-bold font-mono">{item.quantity}</span>
                    <button
                      onClick={() => addToCart(item.product, 1)}
                      className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-bold"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="w-14 text-right font-black font-mono">
                    {formatCurrency(item.product.price * item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            {/* Payment form */}
            {renderCheckoutForm(
              paymentMethod,
              setPaymentMethod,
              cartTotal,
              cashGiven,
              setCashGiven,
              handleAddCash,
              changeDue,
              selectedCustomerId,
              setSelectedCustomerId,
              customers,
              selectedCustomer,
              remainingCreditBeforeSale,
              willExceedLimit,
              isExactOrSufficientCash,
              handleProcessSale,
              isProcessing,
              cart.length === 0
            )}

          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL: SELECTOR DE CANTIDAD RÁPIDA                           */}
      {/* ============================================================ */}
      {quantityModalProduct && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xs w-full p-5 shadow-2xl space-y-4">
            <div>
              <h4 className="text-sm font-black text-slate-900">
                Cantidad a vender
              </h4>
              <p className="text-xs text-slate-600 mt-0.5 truncate">
                {quantityModalProduct.name}
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 py-2">
              <button
                onClick={() => setModalQty(Math.max(1, modalQty - 1))}
                className="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center font-black text-lg"
              >
                -
              </button>
              <input
                type="number"
                min="1"
                value={modalQty}
                onChange={(e) => setModalQty(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 h-12 text-center font-mono font-black text-xl rounded-2xl border-2 border-slate-300 focus:border-emerald-600 outline-none"
              />
              <button
                onClick={() => setModalQty(modalQty + 1)}
                className="w-12 h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center font-black text-lg"
              >
                +
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleConfirmCustomQty}
                className="w-full min-h-[44px] bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl"
              >
                Confirmar
              </button>
              <button
                onClick={() => setQuantityModalProduct(null)}
                className="w-full min-h-[44px] bg-slate-100 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

/**
 * Subcomponent to render payment method selection, cash change calculator and fiado customer chooser
 */
function renderCheckoutForm(
  paymentMethod: PaymentMethod,
  setPaymentMethod: (m: PaymentMethod) => void,
  cartTotal: number,
  cashGiven: string,
  setCashGiven: (v: string) => void,
  handleAddCash: (a: number) => void,
  changeDue: number,
  selectedCustomerId: string,
  setSelectedCustomerId: (id: string) => void,
  customers: any[],
  selectedCustomer: any,
  remainingCreditBeforeSale: number,
  willExceedLimit: boolean,
  isExactOrSufficientCash: boolean,
  handleProcessSale: () => void,
  isProcessing: boolean,
  isCartEmpty: boolean
) {
  return (
    <div className="space-y-4 pt-3 border-t border-slate-100">
      
      {/* Total display */}
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
          Total a Cobrar
        </span>
        <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
          {formatCurrency(cartTotal)}
        </span>
      </div>

      {/* Payment Method Big Buttons (48px touch minimum) */}
      <div className="space-y-1.5">
        <label className="block text-xs font-bold text-slate-700">
          Forma de Pago:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { id: 'Efectivo', label: 'Efectivo', icon: Banknote },
            { id: 'Yape', label: 'Yape', icon: Smartphone },
            { id: 'Plin', label: 'Plin', icon: Smartphone },
            { id: 'Fiado', label: 'Fiado', icon: BookMarked }
          ].map((pm) => {
            const Icon = pm.icon;
            const isSelected = paymentMethod === pm.id;
            return (
              <button
                key={pm.id}
                type="button"
                onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                className={`min-h-[48px] p-2.5 rounded-2xl flex flex-col items-center justify-center gap-1 font-bold text-xs transition border-2 ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-black shadow-sm'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-emerald-700' : 'text-slate-500'}`} />
                <span>{pm.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* EFECTIVO: Calculadora de Vuelto con billetes y monedas */}
      {paymentMethod === 'Efectivo' && (
        <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">
              Pagó con:
            </span>
            <div className="relative w-32">
              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">S/</span>
              <input
                type="number"
                step="0.5"
                placeholder={cartTotal.toFixed(2)}
                value={cashGiven}
                onChange={(e) => setCashGiven(e.target.value)}
                className="w-full pl-7 pr-2 py-1.5 bg-white text-xs font-mono font-black text-right rounded-xl border border-slate-300 focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          {/* Denominación rápida de billetes peruanos */}
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-500">
              Billetes y monedas comunes:
            </span>
            <div className="grid grid-cols-4 gap-1.5 text-xs font-bold">
              {[10, 20, 50, 100].map((billete) => (
                <button
                  key={billete}
                  type="button"
                  onClick={() => handleAddCash(billete)}
                  className="py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 shadow-xs active:scale-95 transition"
                >
                  S/ {billete}
                </button>
              ))}
            </div>
          </div>

          {/* Vuelto display */}
          <div className="pt-1.5 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-700">
              Vuelto a entregar:
            </span>
            <span className="text-base font-black text-emerald-700 font-mono">
              {formatCurrency(changeDue)}
            </span>
          </div>
        </div>
      )}

      {/* FIADO: Seleccionar vecino, saldo actual y tope */}
      {paymentMethod === 'Fiado' && (
        <div className="bg-amber-50/80 p-3.5 rounded-2xl border-2 border-amber-300 space-y-2.5">
          <div>
            <label className="block text-xs font-bold text-amber-950 mb-1">
              ¿A qué vecino se le anota el fiado?
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full p-2.5 bg-white text-xs font-bold rounded-xl border border-amber-300 text-slate-900 outline-none"
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · Saldo actual: {formatCurrency(c.balance)} (Tope: {formatCurrency(c.creditLimit)})
                </option>
              ))}
            </select>
          </div>

          {selectedCustomer && (
            <div className="text-xs space-y-1 text-slate-700 pt-1 border-t border-amber-200">
              <div className="flex justify-between">
                <span>Saldo pendiente hoy:</span>
                <span className="font-bold font-mono">{formatCurrency(selectedCustomer.balance)}</span>
              </div>
              <div className="flex justify-between">
                <span>Tope acordado:</span>
                <span className="font-bold font-mono">{formatCurrency(selectedCustomer.creditLimit)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Disponible antes de superar tope:</span>
                <span className={remainingCreditBeforeSale < 0 ? 'text-red-700' : 'text-emerald-700'}>
                  {formatCurrency(Math.max(0, remainingCreditBeforeSale))}
                </span>
              </div>

              {willExceedLimit && (
                <div className="mt-2 p-2 bg-red-100 border border-red-300 rounded-xl text-red-900 font-bold flex items-center gap-1.5 text-[11px]">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-700" />
                  <span>Atención Don Pepe: Con esta compra superará su tope de {formatCurrency(selectedCustomer.creditLimit)}.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Botón principal de Confirmar Cobro (con alto contraste AA) */}
      <button
        onClick={handleProcessSale}
        disabled={isCartEmpty || isProcessing || !isExactOrSufficientCash}
        className={`w-full min-h-[50px] font-black text-sm rounded-2xl shadow-md flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer ${
          isCartEmpty || !isExactOrSufficientCash
            ? 'bg-slate-300 text-slate-600 cursor-not-allowed border border-slate-300'
            : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-800/20'
        }`}
      >
        <Check className="w-5 h-5" />
        <span>
          {isProcessing 
            ? 'REGISTRANDO...' 
            : paymentMethod === 'Fiado' 
            ? 'ANOTAR EN CUADERNO DE FIADOS' 
            : `COBRAR ${formatCurrency(cartTotal)} (${paymentMethod.toUpperCase()})`}
        </span>
      </button>

      {/* Deshabilitado por falta de efectivo */}
      {!isExactOrSufficientCash && paymentMethod === 'Efectivo' && (
        <p className="text-[11px] font-bold text-red-600 text-center">
          El monto pagado debe ser igual o mayor al total ({formatCurrency(cartTotal)}).
        </p>
      )}

    </div>
  );
}
