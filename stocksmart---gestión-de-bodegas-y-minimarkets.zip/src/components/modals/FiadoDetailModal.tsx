import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { CustomerFiado } from '../../types';
import { X, Coins, Send, MapPin, Phone, Edit2, Check, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { formatCurrency } from '../../utils/helpers';

interface FiadoDetailModalProps {
  customerId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenAbono: (customer: CustomerFiado) => void;
  onOpenWhatsApp: (customer: CustomerFiado) => void;
}

export const FiadoDetailModal: React.FC<FiadoDetailModalProps> = ({
  customerId,
  isOpen,
  onClose,
  onOpenAbono,
  onOpenWhatsApp
}) => {
  const { customers, updateCreditLimit } = useBodega();
  
  // Always read up-to-date customer directly from context
  const customer = customers.find(c => c.id === customerId);

  const [isEditingLimit, setIsEditingLimit] = useState(false);
  const [newLimit, setNewLimit] = useState<number>(100);

  useEffect(() => {
    if (customer) {
      setNewLimit(customer.creditLimit);
      setIsEditingLimit(false);
    }
  }, [customer?.id, customer?.creditLimit]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !customer) return null;

  const handleSaveLimit = () => {
    updateCreditLimit(customer.id, newLimit);
    setIsEditingLimit(false);
  };

  const isOverLimit = customer.balance > customer.creditLimit;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-black text-lg">
              {customer.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 leading-tight">
                {customer.name}
              </h3>
              <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{customer.reference}</span>
                <span className="text-slate-300">•</span>
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>{customer.phone}</span>
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-600" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Card & Credit Limit editor */}
        <div className="my-3 bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                Saldo Actual en Libreta
              </span>
              <p className={`text-2xl font-black font-mono mt-0.5 ${isOverLimit ? 'text-red-700' : 'text-slate-900'}`}>
                {formatCurrency(customer.balance)}
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                Tope Acordado
              </span>
              {!isEditingLimit ? (
                <div className="flex items-center gap-1.5 justify-end mt-0.5">
                  <span className="text-base font-black font-mono text-slate-800">
                    {formatCurrency(customer.creditLimit)}
                  </span>
                  <button
                    onClick={() => { setNewLimit(customer.creditLimit); setIsEditingLimit(true); }}
                    className="p-1.5 hover:bg-slate-200 rounded-lg text-slate-600 cursor-pointer"
                    title="Editar tope de fiado"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1 justify-end mt-0.5">
                  <input
                    type="number"
                    value={newLimit}
                    onChange={(e) => setNewLimit(parseFloat(e.target.value) || 0)}
                    className="w-24 p-1.5 text-xs font-mono font-bold border rounded-lg bg-white"
                  />
                  <button
                    onClick={handleSaveLimit}
                    className="p-1.5 bg-emerald-600 text-white rounded-lg cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Quick status notice */}
          {isOverLimit ? (
            <div className="p-2.5 bg-red-100 rounded-xl text-red-900 text-xs font-bold">
              ⚠️ Superó su tope por {formatCurrency(customer.balance - customer.creditLimit)}. Sugerido no fiar hasta abono.
            </div>
          ) : (
            <div className="flex justify-between text-xs text-slate-600 font-medium">
              <span>Crédito disponible antes del tope:</span>
              <strong className="text-emerald-700 font-mono font-bold">
                {formatCurrency(customer.creditLimit - customer.balance)}
              </strong>
            </div>
          )}
        </div>

        {/* Movements History Ledger */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 my-1">
          <div className="flex items-center justify-between pb-1">
            <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">
              Historial de Compras y Abonos ({customer.movements.length})
            </h4>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {customer.movements.map((mov) => {
              const isAbono = mov.amount < 0;
              return (
                <div key={mov.id} className="py-2.5 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isAbono ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {isAbono ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 leading-tight">
                        {mov.description}
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {mov.date} {mov.ticketNumber ? `• ${mov.ticketNumber}` : ''}
                      </p>
                    </div>
                  </div>

                  <span className={`font-mono font-black text-xs ${
                    isAbono ? 'text-emerald-700' : 'text-slate-900'
                  }`}>
                    {isAbono ? `- ${formatCurrency(Math.abs(mov.amount))}` : `+ ${formatCurrency(mov.amount)}`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
          <button
            onClick={() => { onClose(); onOpenAbono(customer); }}
            className="min-h-[46px] bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-2xl flex items-center justify-center gap-2 shadow cursor-pointer active:scale-95"
          >
            <Coins className="w-4 h-4 text-emerald-400" />
            <span>Registrar Abono</span>
          </button>

          <button
            onClick={() => { onClose(); onOpenWhatsApp(customer); }}
            className="min-h-[46px] bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-2xl flex items-center justify-center gap-2 shadow cursor-pointer active:scale-95"
          >
            <Send className="w-4 h-4" />
            <span>Enviar WhatsApp</span>
          </button>
        </div>

      </div>
    </div>
  );
};
