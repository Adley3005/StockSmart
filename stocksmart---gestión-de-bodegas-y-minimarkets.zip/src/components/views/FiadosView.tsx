import React, { useState, useMemo } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { CustomerFiado } from '../../types';
import { 
  UserPlus, 
  Send, 
  Coins, 
  Eye, 
  EyeOff, 
  Clock, 
  MapPin, 
  Phone, 
  AlertCircle, 
  CheckCircle2, 
  FileText,
  Search,
  BookOpen
} from 'lucide-react';
import { formatCurrency, maskPhone } from '../../utils/helpers';

interface FiadosViewProps {
  onOpenAbonoModal: (customer: CustomerFiado) => void;
  onOpenWhatsAppReminder: (customer: CustomerFiado) => void;
  onOpenCustomerDetail: (customer: CustomerFiado) => void;
  onOpenNewCustomerModal: () => void;
}

export const FiadosView: React.FC<FiadosViewProps> = ({
  onOpenAbonoModal,
  onOpenWhatsAppReminder,
  onOpenCustomerDetail,
  onOpenNewCustomerModal
}) => {
  const { customers, fiadosSummary } = useBodega();

  // Search input
  const [searchQuery, setSearchQuery] = useState('');

  // Unmasked phone toggles (by customerId)
  const [unmaskedPhones, setUnmaskedPhones] = useState<Record<string, boolean>>({});

  const togglePhoneMask = (e: React.MouseEvent, customerId: string) => {
    e.stopPropagation();
    setUnmaskedPhones(prev => ({ ...prev, [customerId]: !prev[customerId] }));
  };

  // Default ordering: highest risk first (% of credit limit or over limit)
  const sortedCustomers = useMemo(() => {
    return [...customers]
      .filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.reference.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .sort((a, b) => {
        const ratioA = a.balance / Math.max(1, a.creditLimit);
        const ratioB = b.balance / Math.max(1, b.creditLimit);
        return ratioB - ratioA; // Higher risk first
      });
  }, [customers, searchQuery]);

  return (
    <div className="space-y-4 pb-12 select-none">
      
      {/* ============================================================ */}
      {/* 1. RESUMEN DEL CUADERNO (TOTAL POR COBRAR, VECINOS Y TOPES)  */}
      {/* ============================================================ */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        
        {/* Total Fiado por Cobrar */}
        <div className="bg-slate-900 text-white rounded-3xl p-4 sm:p-5 shadow-sm border border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Total Fiado por Cobrar
            </span>
            <p className="text-2xl sm:text-3xl font-black text-amber-400 mt-1 font-mono">
              {formatCurrency(fiadosSummary.totalDebt)}
            </p>
          </div>
          <p className="text-xs text-slate-400 mt-2 font-medium">
            Dinero de la bodega en la calle
          </p>
        </div>

        {/* Vecinos con Deuda */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
              Vecinos con Deuda
            </span>
            <p className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 font-mono">
              {fiadosSummary.debtorCount} {fiadosSummary.debtorCount === 1 ? 'vecino' : 'vecinos'}
            </p>
          </div>
          <p className="text-xs text-emerald-700 font-semibold mt-2">
            Todos con libreta activa en la bodega
          </p>
        </div>

        {/* Vecinos que superan su tope */}
        <div className="bg-rose-50 border-2 border-rose-300 rounded-3xl p-4 sm:p-5 shadow-sm flex flex-col justify-between">
          <div>
            <span className="text-xs font-black text-rose-900 uppercase tracking-wide flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-rose-700" />
              <span>Superan su Tope</span>
            </span>
            <p className="text-2xl sm:text-3xl font-black text-rose-900 mt-1 font-mono">
              {fiadosSummary.overLimitCount} {fiadosSummary.overLimitCount === 1 ? 'vecino' : 'vecinos'}
            </p>
          </div>
          <p className="text-xs text-rose-800 font-bold mt-2">
            No fiar más hasta que abonen
          </p>
        </div>

      </div>

      {/* ============================================================ */}
      {/* 2. BARRA DE ACCIÓN Y BUSCADOR DE VECINOS                     */}
      {/* ============================================================ */}
      <div className="bg-white rounded-3xl p-3 sm:p-4 shadow-sm border border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nombre de vecino o referencia..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 bg-slate-50 text-sm font-medium rounded-2xl border border-slate-200 focus:outline-none focus:border-emerald-600 focus:bg-white"
          />
        </div>

        {/* Anotar nuevo vecino */}
        <button
          onClick={onOpenNewCustomerModal}
          className="min-h-[46px] px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs sm:text-sm rounded-2xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Anotar nuevo vecino en cuaderno</span>
        </button>

      </div>

      {/* ============================================================ */}
      {/* 3. LISTA DE TARJETAS POR VECINO (ORDEN: MÁS RIESGO PRIMERO)  */}
      {/* ============================================================ */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1 text-xs text-slate-500 font-medium">
          <span>Ordenados por mayor porcentaje de deuda respecto al tope</span>
          <span>{sortedCustomers.length} clientes</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {sortedCustomers.map((customer) => {
            const isOverLimit = customer.balance > customer.creditLimit;
            const usagePercent = Math.min(100, Math.round((customer.balance / Math.max(1, customer.creditLimit)) * 100));
            const isPhoneRevealed = unmaskedPhones[customer.id] || false;

            // Umbral de color para barra de uso de tope:
            // < 70 % verde, 70–99 % ámbar, ≥ 100 % rojo
            let barColor = 'bg-emerald-500';
            let barLabelColor = 'text-emerald-700';
            if (usagePercent >= 100) {
              barColor = 'bg-red-600';
              barLabelColor = 'text-red-700';
            } else if (usagePercent >= 70) {
              barColor = 'bg-amber-500';
              barLabelColor = 'text-amber-800';
            }

            return (
              <div
                key={customer.id}
                onClick={() => onOpenCustomerDetail(customer)}
                className={`bg-white rounded-3xl p-4 sm:p-5 shadow-sm border-2 transition-all cursor-pointer relative flex flex-col justify-between space-y-3.5 hover:shadow-md ${
                  isOverLimit
                    ? 'border-red-300 bg-rose-50/20'
                    : 'border-slate-200'
                }`}
              >
                
                {/* Header: Nombre y referencia */}
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-base font-black text-slate-900 leading-tight">
                        {customer.name}
                      </h3>
                      <p className="text-xs text-slate-600 font-medium flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{customer.reference}</span>
                      </p>
                    </div>

                    {/* Teléfono Enmascarado con botón de ojo */}
                    <div 
                      onClick={(e) => togglePhoneMask(e, customer.id)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono font-bold transition shrink-0"
                      title="Ver número de teléfono"
                    >
                      <Phone className="w-3 h-3 text-slate-500" />
                      <span>{isPhoneRevealed ? customer.phone : maskPhone(customer.phone)}</span>
                      {isPhoneRevealed ? (
                        <EyeOff className="w-3.5 h-3.5 text-slate-500 ml-0.5" />
                      ) : (
                        <Eye className="w-3.5 h-3.5 text-slate-500 ml-0.5" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Saldo y Barra de uso de tope */}
                <div className="space-y-1.5 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs font-bold text-slate-600">
                      Saldo adeudado:
                    </span>
                    {/* El rojo se reserva ÚNICAMENTE si supera su tope */}
                    <span className={`text-xl font-black font-mono ${
                      isOverLimit ? 'text-red-700' : 'text-slate-900'
                    }`}>
                      {formatCurrency(customer.balance)}
                    </span>
                  </div>

                  {/* Barra de progreso de uso del tope */}
                  <div className="space-y-1">
                    <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${barColor}`}
                        style={{ width: `${usagePercent}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-semibold">
                      <span className="text-slate-500">
                        Tope: <strong className="text-slate-700 font-mono">{formatCurrency(customer.creditLimit)}</strong>
                      </span>
                      <span className={`font-bold ${barLabelColor}`}>
                        {usagePercent}% usado {isOverLimit && '(SUPERÓ TOPE)'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Días desde último abono */}
                <div className="flex items-center justify-between text-xs font-medium text-slate-600 px-1">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {customer.lastPaymentDaysAgo === 0
                        ? 'Abonó hoy'
                        : `Último abono hace ${customer.lastPaymentDaysAgo} días`}
                    </span>
                  </div>

                  <button
                    onClick={(e) => { e.stopPropagation(); onOpenCustomerDetail(customer); }}
                    className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 hover:underline"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Ver libreta ({customer.movements.length})</span>
                  </button>
                </div>

                {/* Acciones principales de la tarjeta */}
                <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-center gap-2">
                  
                  {/* Acción Principal: Registrar abono */}
                  <button
                    onClick={(e) => { e.stopPropagation(); onOpenAbonoModal(customer); }}
                    className="w-full sm:flex-1 min-h-[44px] bg-slate-900 hover:bg-slate-800 active:scale-98 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition"
                  >
                    <Coins className="w-4 h-4 text-emerald-400" />
                    <span>Registrar abono</span>
                  </button>

                  {/* Acción Secundaria: Recordatorio por WhatsApp */}
                  <button
                    onClick={(e) => { e.stopPropagation(); onOpenWhatsAppReminder(customer); }}
                    className="w-full sm:flex-1 min-h-[44px] bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-950 border border-emerald-300 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 transition"
                  >
                    <Send className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Avisar por WhatsApp</span>
                  </button>

                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
