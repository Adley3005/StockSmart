import React, { useState } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product } from '../../types';
import { 
  AlertTriangle, 
  Ban, 
  Clock, 
  Users, 
  CheckCircle2, 
  Truck, 
  TrendingUp, 
  Flame,
  ChevronRight,
  ShoppingBag,
  Eye,
  EyeOff
} from 'lucide-react';
import { formatCurrency, getExpiryDetails, getStockStatus, formatUnitPlural } from '../../utils/helpers';

interface TodayViewProps {
  onOpenSupplierOrder: () => void;
  onOpenRetireModal: (product: Product) => void;
}

export const TodayView: React.FC<TodayViewProps> = ({
  onOpenSupplierOrder,
  onOpenRetireModal
}) => {
  const { 
    products, 
    stockCounts, 
    customers,
    salesTodayTotal, 
    ticketsTodayCount, 
    topProducts,
    currentDateFormatted,
    setActiveTab,
    setInventoryFilterInitial
  } = useBodega();

  // Top 5 ranking sort metric: 'units' or 'soles'
  const [topSortCriterion, setTopSortCriterion] = useState<'units' | 'soles'>('units');
  // Limit visible alert cards to max 3 per Brief Principle 2
  const [showAllAlerts, setShowAllAlerts] = useState<boolean>(false);

  // Specific product lists for actionable cards
  const expiredProducts = products.filter(p => getExpiryDetails(p).status === 'Vencido');
  const outOfStockProducts = products.filter(p => getStockStatus(p) === 'Agotado');
  const lowStockProducts = products.filter(p => getStockStatus(p) === 'Bajo');
  const expiringSoonProducts = products.filter(p => getExpiryDetails(p).status === 'Por vencer');
  const overLimitCustomers = customers.filter(c => c.balance > c.creditLimit);

  // Check if there are any pending actions today
  const hasPendingActions = 
    expiredProducts.length > 0 || 
    outOfStockProducts.length > 0 || 
    lowStockProducts.length > 0 || 
    expiringSoonProducts.length > 0 || 
    overLimitCustomers.length > 0;

  // Max value for Top 5 proportional bars
  const maxUnits = Math.max(...topProducts.map(tp => tp.unitsSold), 1);
  const maxSoles = Math.max(...topProducts.map(tp => tp.totalSalesSol), 1);

  const sortedTopProducts = [...topProducts].sort((a, b) => {
    return topSortCriterion === 'units'
      ? b.unitsSold - a.unitsSold
      : b.totalSalesSol - a.totalSalesSol;
  });

  const handleFilterToProducts = (filter: 'agotados' | 'bajos' | 'vencidos' | 'por_vencer') => {
    setInventoryFilterInitial(filter);
    setActiveTab('productos');
  };

  // Compile active alert cards in strict order of urgency:
  // 1. Vencidos -> 2. Agotados -> 3. Bajos -> 4. Por vencer -> 5. Fiados que pasaron su tope
  const alertCards: { id: string; element: React.ReactNode }[] = [];

  if (expiredProducts.length > 0) {
    alertCards.push({
      id: 'vencidos',
      element: (
        <div key="vencidos" className="bg-rose-950 text-white rounded-2xl p-4 shadow-sm border border-rose-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-900/90 text-rose-300 flex items-center justify-center shrink-0 mt-0.5">
              <Ban className="w-5 h-5 text-rose-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-rose-200">
                  {expiredProducts.length} {expiredProducts.length === 1 ? 'producto vencido' : 'productos vencidos'}
                </span>
                <span className="bg-rose-500/30 text-rose-200 text-[10px] font-extrabold px-2 py-0.5 rounded border border-rose-500/40">
                  URGENTE
                </span>
              </div>
              <p className="text-xs text-rose-200/80 mt-1">
                Ejemplos: {expiredProducts.slice(0, 3).map(p => p.name).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => onOpenRetireModal(expiredProducts[0])}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow cursor-pointer"
            >
              <span>Retirar de venta</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )
    });
  }

  if (outOfStockProducts.length > 0) {
    alertCards.push({
      id: 'agotados',
      element: (
        <div key="agotados" className="bg-red-50 rounded-2xl p-4 shadow-sm border-2 border-red-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-200 text-red-800 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-red-950">
                  {outOfStockProducts.length} {outOfStockProducts.length === 1 ? 'producto agotado' : 'productos agotados'} (0 uds)
                </span>
                <span className="bg-red-200 text-red-900 text-[10px] font-bold px-2 py-0.5 rounded">
                  Sin existencias
                </span>
              </div>
              <p className="text-xs text-red-800/90 mt-1">
                Ejemplos: {outOfStockProducts.slice(0, 3).map(p => p.name).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onOpenSupplierOrder}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Armar pedido</span>
            </button>
          </div>
        </div>
      )
    });
  }

  if (lowStockProducts.length > 0) {
    alertCards.push({
      id: 'bajos',
      element: (
        <div key="bajos" className="bg-amber-50 rounded-2xl p-4 shadow-sm border-2 border-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-amber-950">
                  {lowStockProducts.length} {lowStockProducts.length === 1 ? 'producto con stock bajo' : 'productos con stock bajo'} (&lt; mínimo)
                </span>
                <span className="bg-amber-200 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded">
                  Reposición
                </span>
              </div>
              <p className="text-xs text-amber-900/90 mt-1">
                Ejemplos: {lowStockProducts.slice(0, 3).map(p => p.name).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onOpenSupplierOrder}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>Armar pedido</span>
            </button>
          </div>
        </div>
      )
    });
  }

  if (expiringSoonProducts.length > 0) {
    alertCards.push({
      id: 'por_vencer',
      element: (
        <div key="por_vencer" className="bg-amber-50/70 rounded-2xl p-4 shadow-sm border border-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mt-0.5">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-amber-950">
                  {expiringSoonProducts.length} {expiringSoonProducts.length === 1 ? 'producto por vencer' : 'productos por vencer'} (≤ 7 días)
                </span>
                <span className="bg-amber-200/80 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded">
                  Poner adelante
                </span>
              </div>
              <p className="text-xs text-amber-800/90 mt-1">
                Ejemplos: {expiringSoonProducts.slice(0, 3).map(p => p.name).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => handleFilterToProducts('por_vencer')}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow cursor-pointer"
            >
              <span>Revisar lotes</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )
    });
  }

  if (overLimitCustomers.length > 0) {
    alertCards.push({
      id: 'sobre_tope',
      element: (
        <div key="sobre_tope" className="bg-rose-50 rounded-2xl p-4 shadow-sm border-2 border-rose-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-200 text-rose-800 flex items-center justify-center shrink-0 mt-0.5">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-rose-950">
                  {overLimitCustomers.length} {overLimitCustomers.length === 1 ? 'vecino superó su tope' : 'vecinos superaron su tope'} de crédito
                </span>
                <span className="bg-rose-200 text-rose-900 text-[10px] font-bold px-2 py-0.5 rounded">
                  Tope excedido
                </span>
              </div>
              <p className="text-xs text-rose-900/90 mt-1">
                Ejemplos: {overLimitCustomers.map(c => `${c.name} (${formatCurrency(c.balance)})`).join(', ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('fiados')}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 bg-rose-700 hover:bg-rose-800 active:scale-95 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow cursor-pointer"
            >
              <span>Cobrar / Recordar</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )
    });
  }

  // Principle 2: Max 3 visible at a time unless expanded
  const visibleCards = showAllAlerts ? alertCards : alertCards.slice(0, 3);

  return (
    <div className="space-y-5 pb-6">
      
      {/* 1. WELCOME & ACTION BANNER */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-sm border border-slate-200/90 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-0.5 rounded-full font-bold">
              Turno en curso
            </span>
            <span className="text-slate-400 text-xs">•</span>
            <span className="text-xs font-semibold text-slate-500">
              {currentDateFormatted}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            Para hacer hoy en la bodega
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Prioridades automáticas para que Don Pepe no pierda ventas ni mercadería.
          </p>
        </div>

        {/* Big Action Button: Armar Pedido al Proveedor */}
        <button
          onClick={onOpenSupplierOrder}
          className="w-full md:w-auto min-h-[48px] bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-extrabold text-sm px-5 py-3 rounded-2xl shadow-md transition flex items-center justify-center gap-2.5 cursor-pointer"
        >
          <Truck className="w-5 h-5 shrink-0" />
          <span>Armar pedido al proveedor ({stockCounts.agotados + stockCounts.bajos} items)</span>
        </button>
      </div>

      {/* 2. BLOQUE SUPERIOR: "PARA HACER HOY" (MÁXIMO 3 ALERTAS VISIBLES A LA VEZ) */}
      <section className="space-y-3" aria-labelledby="todo-heading">
        <div className="flex items-center justify-between px-1">
          <h2 id="todo-heading" className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <span>Acciones Prioritarias del Día</span>
            <span className="bg-slate-200 text-slate-700 text-xs px-2 py-0.5 rounded-full font-extrabold">
              {alertCards.length}
            </span>
          </h2>

          {alertCards.length > 3 && (
            <button
              onClick={() => setShowAllAlerts(!showAllAlerts)}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 hover:underline cursor-pointer"
            >
              {showAllAlerts ? (
                <>
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Ver solo 3 prioritarias</span>
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  <span>Ver todas ({alertCards.length})</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Positive Empty State if no pending issues */}
        {!hasPendingActions ? (
          <div className="bg-emerald-50 border-2 border-emerald-200 rounded-3xl p-8 text-center text-emerald-900 space-y-2">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
            <h3 className="text-lg font-black">¡Todo en orden, Don Pepe!</h3>
            <p className="text-xs sm:text-sm text-emerald-700 max-w-md mx-auto">
              No tienes productos vencidos, quiebres de stock ni fiados fuera de límite en este momento.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {visibleCards.map(card => card.element)}
          </div>
        )}
      </section>

      {/* 3. BLOQUE INFERIOR: "CÓMO VA EL TURNO" (100% DERIVADO DE VENTAS) */}
      <section className="bg-white rounded-3xl p-4 sm:p-6 shadow-sm border border-slate-200 space-y-5" aria-labelledby="shift-stats-heading">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h2 id="shift-stats-heading" className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <span>Cómo va el turno</span>
            </h2>
            <p className="text-xs text-slate-500">Métricas reales acumuladas de las transacciones registradas hoy</p>
          </div>

          <button
            onClick={() => setActiveTab('vender')}
            className="self-start sm:self-auto text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Ir al mostrador a cobrar</span>
          </button>
        </div>

        {/* Quick KPI Numbers */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          
          {/* Soles Totales */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 relative overflow-hidden">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Vendido Hoy (Total)
            </span>
            <p className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1 font-mono">
              {formatCurrency(salesTodayTotal)}
            </p>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <span>Suma exacta de tickets cobrados</span>
            </p>
          </div>

          {/* Número de Tickets */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
              Tickets del Turno
            </span>
            <p className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 font-mono">
              {ticketsTodayCount}
            </p>
            <p className="text-[11px] text-slate-500 mt-1 font-medium">
              Ticket promedio: {formatCurrency(ticketsTodayCount > 0 ? salesTodayTotal / ticketsTodayCount : 0)}
            </p>
          </div>

          {/* Ritmo y estado */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold text-emerald-900 uppercase tracking-wide">
                Estado del Cuadre
              </span>
              <p className="text-2xl sm:text-3xl font-black text-emerald-800 mt-1 font-mono">
                100% Cuadrado
              </p>
            </div>
            <p className="text-[11px] text-emerald-700 font-semibold mt-1">
              {ticketsTodayCount > 0 ? 'Cada sol proviene de una venta registrada' : 'Esperando primera venta del turno'}
            </p>
          </div>

        </div>

        {/* Top 5 Products con Toggle y Proporciones Reales */}
        <div className="pt-2">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500" />
              <h3 className="text-sm font-black text-slate-900">
                Top Productos Más Vendidos Hoy
              </h3>
            </div>

            {/* Selector de Criterio: Unidades o Soles */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold self-stretch sm:self-auto">
              <button
                onClick={() => setTopSortCriterion('units')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  topSortCriterion === 'units'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Por Unidades
              </button>
              <button
                onClick={() => setTopSortCriterion('soles')}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  topSortCriterion === 'soles'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                Por Soles (S/)
              </button>
            </div>
          </div>

          {/* Lista con barras proporcionales reales (sin distorsión mínima forzada) */}
          {sortedTopProducts.length === 0 ? (
            <div className="py-6 text-center text-slate-400 text-xs">
              Aún no se han cobrado ventas en este turno.
            </div>
          ) : (
            <div className="space-y-3">
              {sortedTopProducts.map((item, idx) => {
                const currentVal = topSortCriterion === 'units' ? item.unitsSold : item.totalSalesSol;
                const maxVal = topSortCriterion === 'units' ? maxUnits : maxSoles;
                // Proporción matemática pura
                const percent = Math.min(100, Math.round((currentVal / maxVal) * 100));

                return (
                  <div key={item.product.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <div className="flex items-center gap-2 truncate">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-800 text-[11px] font-black flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-slate-900 truncate font-bold">
                          {item.product.name}
                        </span>
                      </div>

                      <div className="text-right shrink-0 font-mono">
                        {topSortCriterion === 'units' ? (
                          <span className="text-slate-900 font-bold">
                            {formatUnitPlural(item.unitsSold, item.product.unit)}
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-black">
                            {formatCurrency(item.totalSalesSol)}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Proportional Bar */}
                    <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          idx === 0 
                            ? 'bg-emerald-600' 
                            : idx === 1 
                            ? 'bg-emerald-500' 
                            : 'bg-teal-500'
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>

      </section>

    </div>
  );
};
