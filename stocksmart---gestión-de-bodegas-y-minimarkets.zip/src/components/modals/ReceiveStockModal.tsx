import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product } from '../../types';
import { Truck, AlertTriangle, X, Check } from 'lucide-react';
import { formatDateShort, getExpiryDetails, formatUnitPlural } from '../../utils/helpers';

interface ReceiveStockModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenMermaForProduct?: (product: Product) => void;
}

export const ReceiveStockModal: React.FC<ReceiveStockModalProps> = ({ 
  product, 
  isOpen, 
  onClose,
  onOpenMermaForProduct
}) => {
  const { receiveStock } = useBodega();

  const [quantity, setQuantity] = useState<number>(12);
  const [newExpiryDate, setNewExpiryDate] = useState<string>('');

  useEffect(() => {
    if (product) {
      setQuantity(product.minStock > 0 ? product.minStock : 12);
      // Empty by default to force conscious entry by bodeguero, or product's active expiry
      setNewExpiryDate(product.expiryDate || '');
    }
  }, [product]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const expiryInfo = getExpiryDetails(product);
  const isCurrentlyExpired = expiryInfo.status === 'Vencido';

  const handleConfirm = () => {
    if (!newExpiryDate) {
      alert('Por favor ingrese la fecha de vencimiento que figura en el empaque del nuevo lote.');
      return;
    }
    if (quantity > 0) {
      receiveStock(product.id, quantity, newExpiryDate);
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200 animate-slide-up">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Recibir Mercadería
              </h3>
              <p className="text-[11px] text-slate-500">Ingreso de nuevo lote del proveedor</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-2 rounded-xl" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning if current stock is expired */}
        {isCurrentlyExpired && (
          <div className="bg-rose-50 border border-rose-300 rounded-2xl p-3 text-xs text-rose-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-black text-rose-950">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Atención: {product.stock} {product.unit}s vencidas en góndola</span>
            </div>
            <p className="text-[11px] text-rose-800 leading-snug">
              El nuevo lote no ocultará los productos vencidos. Recuerda retirarlos de venta registrando una merma.
            </p>
            {onOpenMermaForProduct && (
              <button
                type="button"
                onClick={() => { onClose(); onOpenMermaForProduct(product); }}
                className="text-[11px] font-bold text-rose-950 underline mt-1"
              >
                Dar de baja producto vencido ahora
              </button>
            )}
          </div>
        )}

        {/* Product details */}
        <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs space-y-1">
          <p className="font-extrabold text-slate-900 text-sm">{product.name}</p>
          <div className="flex justify-between text-slate-600 font-medium pt-1">
            <span>Stock actual: <strong className="font-mono text-slate-900">{formatUnitPlural(product.stock, product.unit)}</strong></span>
            <span>Mínimo: {product.minStock} {product.unit}</span>
          </div>
        </div>

        {/* Quantity to add */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-700">
            Cantidad de {product.unit}s recibidas:
          </label>
          <div className="flex items-center justify-center gap-3 py-1">
            <button
              type="button"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-11 h-11 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xl flex items-center justify-center cursor-pointer active:scale-95"
            >
              -
            </button>
            <input
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-24 h-11 text-center font-mono font-black text-xl rounded-xl border-2 border-slate-300 focus:border-emerald-600 outline-none"
            />
            <button
              type="button"
              onClick={() => setQuantity(quantity + 1)}
              className="w-11 h-11 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xl flex items-center justify-center cursor-pointer active:scale-95"
            >
              +
            </button>
          </div>
        </div>

        {/* New expiry date (Mandatory) */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-700">
              Fecha de vencimiento en empaque:
            </label>
            <span className="text-[10px] text-emerald-700 font-bold">*Requerido</span>
          </div>
          <input
            type="date"
            required
            value={newExpiryDate}
            onChange={(e) => setNewExpiryDate(e.target.value)}
            className="w-full p-2.5 bg-white text-xs font-bold font-mono rounded-xl border-2 border-slate-300 outline-none focus:border-emerald-600 text-center text-sm"
          />
          {newExpiryDate && (
            <p className="text-[11px] text-slate-500 font-medium">
              Vence el: <strong>{formatDateShort(newExpiryDate)}</strong>
            </p>
          )}
        </div>

        {/* Resulting stock preview */}
        <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 flex justify-between font-bold items-center">
          <span>Nuevo stock resultante:</span>
          <span className="font-mono text-base font-black text-emerald-800">
            {product.stock + quantity} {product.unit}
          </span>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={handleConfirm}
            className="min-h-[46px] bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
          >
            <Check className="w-4 h-4" />
            <span>Confirmar Ingreso</span>
          </button>
          <button
            onClick={onClose}
            className="min-h-[46px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Cancelar
          </button>
        </div>

      </div>
    </div>
  );
};
