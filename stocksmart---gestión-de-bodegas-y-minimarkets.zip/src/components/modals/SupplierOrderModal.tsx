import React, { useState, useEffect, useMemo } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Truck, Copy, Check, X, Send, Plus, Minus, Phone } from 'lucide-react';
import { calculateSuggestedOrderQty, formatLongDate, formatUnitPlural } from '../../utils/helpers';

interface SupplierOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupplierOrderModal: React.FC<SupplierOrderModalProps> = ({ isOpen, onClose }) => {
  const { products, showToast } = useBodega();

  // Supplier items computed on the fly from current live products
  const liveOrderItems = useMemo(() => {
    return products
      .filter((p) => p.stock < p.minStock)
      .map((p) => ({
        product: p,
        suggestedQty: calculateSuggestedOrderQty(p)
      }))
      .sort((a, b) => a.product.stock - b.product.stock);
  }, [products]);

  // Quantities editable by user, re-initialized whenever modal opens
  const [orderQuantities, setOrderQuantities] = useState<Record<string, number>>({});
  const [supplierPhone, setSupplierPhone] = useState<string>('987112233');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const initial: Record<string, number> = {};
      liveOrderItems.forEach(item => {
        initial[item.product.id] = item.suggestedQty;
      });
      setOrderQuantities(initial);
      setCopied(false);
    }
  }, [isOpen, liveOrderItems]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleQtyChange = (productId: string, delta: number) => {
    setOrderQuantities(prev => {
      const current = prev[productId] !== undefined ? prev[productId] : 1;
      return {
        ...prev,
        [productId]: Math.max(0, current + delta)
      };
    });
  };

  // Generate WhatsApp message text without numbering gaps
  const generateWhatsAppMessage = () => {
    let msg = `*PEDIDO PARA PROVEEDOR - MINIMARKET DON PEPE*\n`;
    msg += `Fecha: ${formatLongDate()}\n`;
    msg += `Por favor cotizar y programar despacho de los siguientes productos:\n\n`;

    let itemCounter = 1;
    liveOrderItems.forEach((item) => {
      const qty = orderQuantities[item.product.id] ?? item.suggestedQty;
      if (qty > 0) {
        msg += `${itemCounter}. *${item.product.name}*\n`;
        msg += `   • Pedir: *${formatUnitPlural(qty, item.product.unit)}*\n`;
        msg += `   • Stock actual en bodega: ${formatUnitPlural(item.product.stock, item.product.unit)}\n\n`;
        itemCounter++;
      }
    });

    msg += `Atentamente, Don Pepe (Minimarket Don Pepe). ¡Muchas gracias!`;
    return msg;
  };

  const handleCopy = () => {
    const text = generateWhatsAppMessage();
    navigator.clipboard?.writeText(text);
    setCopied(true);
    showToast('¡Texto copiado! Listo para enviar por WhatsApp al proveedor.', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleOpenWhatsApp = () => {
    const text = generateWhatsAppMessage();
    const cleanPhone = supplierPhone.replace(/\D/g, '');
    const phoneParam = cleanPhone ? `51${cleanPhone.slice(-9)}` : '';
    const url = phoneParam 
      ? `https://wa.me/${phoneParam}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-xl w-full p-4 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Armar Pedido al Proveedor
              </h3>
              <p className="text-xs text-slate-500">
                {liveOrderItems.length} productos agotados o por debajo del mínimo
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-600" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Supplier Phone Input */}
        <div className="pt-2 pb-1 flex items-center justify-between gap-2 text-xs">
          <span className="font-bold text-slate-700 flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-emerald-600" />
            <span>Celular proveedor:</span>
          </span>
          <div className="relative w-44">
            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-[11px]">+51</span>
            <input
              type="tel"
              value={supplierPhone}
              onChange={(e) => setSupplierPhone(e.target.value)}
              placeholder="987654321"
              className="w-full pl-9 pr-2 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300"
            />
          </div>
        </div>

        {/* List of items to order */}
        <div className="my-2 overflow-y-auto flex-1 space-y-2.5 pr-1">
          {liveOrderItems.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-1">
              <p className="text-sm font-bold text-slate-700">No hay productos que requieran reposición</p>
              <p className="text-xs">Todo el inventario supera los niveles mínimos de seguridad.</p>
            </div>
          ) : (
            liveOrderItems.map(({ product, suggestedQty }) => {
              const currentQty = orderQuantities[product.id] ?? suggestedQty;
              const isAgotado = product.stock === 0;

              return (
                <div
                  key={product.id}
                  className={`p-3 rounded-2xl border-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                    isAgotado
                      ? 'bg-red-50/60 border-red-200'
                      : 'bg-amber-50/60 border-amber-200'
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-slate-900">
                        {product.name}
                      </span>
                      <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                        isAgotado ? 'bg-red-200 text-red-900' : 'bg-amber-200 text-amber-950'
                      }`}>
                        {isAgotado ? 'AGOTADO (0)' : 'STOCK BAJO'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mt-0.5">
                      Stock: <strong className="font-mono">{formatUnitPlural(product.stock, product.unit)}</strong> (Mínimo: {product.minStock})
                    </p>
                  </div>

                  {/* Quantity editor */}
                  <div className="flex items-center gap-2 bg-white px-2.5 py-1.5 rounded-xl border border-slate-300 shadow-xs self-end sm:self-auto">
                    <span className="text-[11px] font-bold text-slate-500">Pedir:</span>
                    <button
                      type="button"
                      onClick={() => handleQtyChange(product.id, -1)}
                      className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center font-bold active:scale-95 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-9 text-center font-mono font-black text-xs text-slate-900">
                      {currentQty}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleQtyChange(product.id, 1)}
                      className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center font-bold active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs text-slate-600 font-semibold">{product.unit}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Bottom actions */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row gap-2">
          <button
            onClick={handleOpenWhatsApp}
            disabled={liveOrderItems.length === 0}
            className="flex-1 min-h-[46px] bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>ENVIAR POR WHATSAPP</span>
          </button>

          <button
            onClick={handleCopy}
            disabled={liveOrderItems.length === 0}
            className="min-h-[46px] px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? '¡Copiado!' : 'Copiar texto'}</span>
          </button>

          <button
            onClick={onClose}
            className="min-h-[46px] px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
};
