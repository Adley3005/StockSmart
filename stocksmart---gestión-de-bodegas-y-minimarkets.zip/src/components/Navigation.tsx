import React from 'react';
import { useBodega } from '../context/BodegaContext';
import { ActiveTab } from '../types';
import { 
  Sun, 
  ShoppingCart, 
  Boxes, 
  BookOpen, 
  Palette,
  Truck,
  ClipboardCheck,
  Store,
  Wifi,
  WifiOff,
  UserCheck,
  RefreshCw,
  Sparkles
} from 'lucide-react';

interface NavigationProps {
  onOpenSupplierModal: () => void;
  onOpenStockCount?: () => void;
  onOpenDesignTokens: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  onOpenSupplierModal,
  onOpenStockCount,
  onOpenDesignTokens
}) => {
  const { 
    activeTab, 
    setActiveTab, 
    cartItemsCount, 
    stockCounts, 
    expiryCounts,
    fiadosSummary,
    isOnline,
    toggleOnline,
    pendingSyncCount,
    syncOfflineData,
    shift,
    toggleShift,
    currentDateFormatted
  } = useBodega();

  // Urgent inventory alerts count (Agotados + Vencidos)
  const urgentInventoryCount = stockCounts.agotados + expiryCounts.vencidos;

  const tabs: { id: ActiveTab; label: string; shortLabel: string; icon: React.ReactNode; badge?: number | string; badgeColor?: string; subtitle: string }[] = [
    {
      id: 'hoy',
      label: 'HOY',
      shortLabel: 'Hoy',
      subtitle: 'Dashboard y Alertas',
      icon: <Sun className="w-5 h-5" />
    },
    {
      id: 'vender',
      label: 'VENDER',
      shortLabel: 'Vender',
      subtitle: 'Mostrador y Cobro Rápido',
      icon: <ShoppingCart className="w-5 h-5" />,
      badge: cartItemsCount > 0 ? cartItemsCount : undefined,
      badgeColor: 'bg-emerald-500 text-white'
    },
    {
      id: 'productos',
      label: 'PRODUCTOS',
      shortLabel: 'Stock',
      subtitle: 'Inventario, Lotes y Mermas',
      icon: <Boxes className="w-5 h-5" />,
      badge: urgentInventoryCount > 0 ? urgentInventoryCount : undefined,
      badgeColor: 'bg-rose-600 text-white'
    },
    {
      id: 'fiados',
      label: 'FIADOS',
      shortLabel: 'Fiados',
      subtitle: 'Cuaderno Digital de Crédito',
      icon: <BookOpen className="w-5 h-5" />,
      badge: fiadosSummary.overLimitCount > 0 ? fiadosSummary.overLimitCount : undefined,
      badgeColor: 'bg-rose-600 text-white'
    }
  ];

  return (
    <>
      {/* ============================================================ */}
      {/* MOBILE BOTTOM NAVIGATION BAR (FIXED AT BOTTOM FOR SCREENS < MD)*/}
      {/* Area táctil mínima de 50px por botón con iconos y texto      */}
      {/* ============================================================ */}
      <nav 
        className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-950 text-slate-400 border-t border-slate-800 z-40 px-1 py-1 shadow-2xl flex justify-around items-stretch select-none"
        aria-label="Navegación principal móvil"
      >
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 min-h-[54px] flex flex-col items-center justify-center gap-0.5 rounded-xl transition-all relative ${
                isActive
                  ? 'text-emerald-400 font-extrabold bg-slate-900 shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 font-bold active:scale-95'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && (
                  <span 
                    className={`absolute -top-1.5 -right-3 text-[10px] font-black min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center border-2 border-slate-950 shadow-sm ${
                      tab.badgeColor || 'bg-emerald-500 text-white'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] tracking-wide mt-0.5 font-bold">
                {tab.shortLabel}
              </span>
            </button>
          );
        })}
      </nav>

      {/* ============================================================ */}
      {/* DESKTOP SIDEBAR NAVIGATION (FIJADO ESTRICTAMENTE A LA IZQUIERDA) */}
      {/* ============================================================ */}
      <aside 
        className="hidden md:flex flex-col w-64 lg:w-72 bg-slate-900 border-r border-slate-800 text-slate-300 fixed top-0 bottom-0 left-0 z-40 justify-between select-none shadow-2xl overflow-y-auto"
        aria-label="Menú principal de escritorio"
      >
        <div className="p-4 space-y-6">
          
          {/* Logo & Store Header at the very top of Sidebar */}
          <div 
            onClick={() => setActiveTab('hoy')}
            className="flex items-center gap-3 p-2 rounded-2xl bg-slate-950/60 border border-slate-800/80 cursor-pointer group hover:border-emerald-500/50 transition-all"
            role="button"
            tabIndex={0}
            title="Ir al inicio"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg text-white font-black group-hover:scale-105 transition-transform shrink-0">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black tracking-tight text-white leading-none">
                  StockSmart
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[9px] font-extrabold px-1.5 py-0.2 rounded border border-emerald-500/40">
                  BODEGA
                </span>
              </div>
              <p className="text-xs font-bold text-emerald-400 truncate mt-0.5">
                Minimarket Don Pepe
              </p>
              <p className="text-[10px] text-slate-500 truncate">
                Lima, Perú · {currentDateFormatted}
              </p>
            </div>
          </div>

          {/* Menú Principal Section */}
          <div className="space-y-2">
            <div className="px-2 flex items-center justify-between">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                Menú Principal
              </span>
              <span className="text-[10px] font-semibold text-emerald-500">
                Don Pepe POS
              </span>
            </div>

            <div className="space-y-1">
              {tabs.map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full min-h-[50px] px-3.5 py-2.5 rounded-xl flex items-center justify-between transition-all text-left group ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950/40 font-black'
                        : 'hover:bg-slate-800 text-slate-300 hover:text-white font-bold'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-1.5 rounded-lg transition-colors ${
                        isActive ? 'bg-emerald-700 text-white' : 'bg-slate-800 text-slate-400 group-hover:text-emerald-400'
                      }`}>
                        {tab.icon}
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-black tracking-wide leading-tight">
                          {tab.label}
                        </div>
                        <div className={`text-[10px] truncate leading-tight mt-0.5 ${
                          isActive ? 'text-emerald-100 font-medium' : 'text-slate-500'
                        }`}>
                          {tab.subtitle}
                        </div>
                      </div>
                    </div>

                    {tab.badge !== undefined && (
                      <span 
                        className={`text-[11px] font-black min-w-[22px] h-5 px-1.5 rounded-full flex items-center justify-center shrink-0 ml-1.5 shadow-sm ${
                          isActive 
                            ? 'bg-white text-emerald-800' 
                            : tab.badgeColor || 'bg-slate-800 text-white border border-slate-700'
                        }`}
                      >
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Action Tools in Desktop Sidebar */}
          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            <div className="px-2">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                Herramientas Rápidas
              </span>
            </div>

            <button
              onClick={onOpenSupplierModal}
              className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700/80 flex items-center justify-between text-xs font-bold transition shadow-xs group"
            >
              <div className="flex items-center gap-2.5">
                <Truck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span>Pedido al Proveedor</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                Sugerido
              </span>
            </button>

            {onOpenStockCount && (
              <button
                onClick={onOpenStockCount}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-800/60 hover:bg-slate-700 text-slate-200 border border-slate-800 flex items-center gap-2.5 text-xs font-semibold transition"
              >
                <ClipboardCheck className="w-4 h-4 text-amber-400" />
                <span>Contar Stock Físico</span>
              </button>
            )}

            <button
              onClick={onOpenDesignTokens}
              className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 flex items-center gap-2.5 text-xs font-medium transition"
            >
              <Palette className="w-4 h-4 text-teal-400" />
              <span>Sistema de Diseño</span>
            </button>
          </div>
        </div>

        {/* Bottom Shift & Sync Controls in Sidebar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40 space-y-3">
          
          {/* Connection status toggle */}
          <div className="flex items-center justify-between text-xs bg-slate-900 p-2.5 rounded-xl border border-slate-800">
            <button
              onClick={toggleOnline}
              className="flex items-center gap-2 text-left font-bold"
              title="Alternar modo en línea / sin conexión"
            >
              <span className={`w-2.5 h-2.5 rounded-full ${
                isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`} />
              <span className={isOnline ? 'text-emerald-300' : 'text-amber-300'}>
                {isOnline ? 'En línea' : 'Sin conexión'}
              </span>
            </button>

            {pendingSyncCount > 0 && isOnline ? (
              <button
                onClick={syncOfflineData}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-2 py-0.5 rounded-md text-[10px] font-black flex items-center gap-1 shadow transition"
                title="Sincronizar ventas pendientes"
              >
                <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                <span>{pendingSyncCount} pend.</span>
              </button>
            ) : (
              <span className="text-[10px] text-slate-500 font-mono">
                {isOnline ? 'Sincronizado' : `${pendingSyncCount} pendientes`}
              </span>
            )}
          </div>

          {/* Turno toggle button */}
          <button
            onClick={toggleShift}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-semibold transition"
            title="Cambiar turno de atención"
          >
            <div className="flex items-center gap-2">
              <UserCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Turno {shift}</span>
            </div>
            <span className="text-[10px] text-slate-500 underline">Cambiar</span>
          </button>

          <div className="text-[10px] text-slate-500 text-center pt-1">
            <span>StockSmart Bodega · v2.5 Lima</span>
          </div>
        </div>

      </aside>
    </>
  );
};
