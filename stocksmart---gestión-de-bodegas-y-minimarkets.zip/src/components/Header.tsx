import React, { useState } from 'react';
import { useBodega } from '../context/BodegaContext';
import { 
  Store, 
  Wifi, 
  WifiOff, 
  UserCheck, 
  Calendar, 
  Palette, 
  Sparkles, 
  Settings, 
  ChevronDown,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

interface HeaderProps {
  onOpenDesignTokens: () => void;
  onOpenSettings: () => void;
  onOpenPlans: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenDesignTokens,
  onOpenSettings,
  onOpenPlans
}) => {
  const { 
    isOnline, 
    toggleOnline, 
    pendingSyncCount, 
    syncOfflineData, 
    shift, 
    cashier, 
    toggleShift, 
    currentDateFormatted,
    activeTab,
    setActiveTab
  } = useBodega();

  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Friendly title per active tab for desktop top bar
  const activeTabTitles: Record<string, { title: string; subtitle: string }> = {
    hoy: { title: 'Hoy (Dashboard)', subtitle: 'Acciones prioritarias y resumen de ventas' },
    vender: { title: 'Vender (Mostrador)', subtitle: 'Cobro rápido, lector de códigos y fiados' },
    productos: { title: 'Productos y Stock', subtitle: 'Catálogo completo, alertas de quiebre y mermas' },
    fiados: { title: 'Cuaderno de Fiados', subtitle: 'Límites de crédito vecinal y registro de abonos' }
  };

  const currentViewInfo = activeTabTitles[activeTab] || activeTabTitles.hoy;

  return (
    <header className="bg-slate-900 text-white sticky top-0 z-30 shadow-md border-b border-slate-800 md:pl-64 lg:pl-72 w-full transition-all">
      {/* Top Banner if Offline */}
      {!isOnline && (
        <div className="bg-amber-500 text-slate-950 px-4 sm:px-6 lg:px-8 py-1.5 text-xs sm:text-sm font-bold flex items-center justify-between">
          <div className="flex items-center gap-2 w-full">
            <WifiOff className="w-4 h-4 text-slate-900 shrink-0" />
            <span className="truncate">
              <strong>Modo Sin Internet:</strong> Las ventas y stock se guardan en este dispositivo.
            </span>
            <span className="ml-auto bg-slate-950 text-amber-300 text-xs px-2 py-0.5 rounded font-mono shrink-0">
              {pendingSyncCount} pendientes
            </span>
          </div>
        </div>
      )}

      {/* Main Header Container */}
      <div className="w-full px-3.5 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-3">
        
        {/* Mobile: Bodega Branding & Name (< MD) */}
        <div 
          onClick={() => setActiveTab('hoy')} 
          className="md:hidden flex items-center gap-2.5 cursor-pointer select-none group"
          role="button"
          tabIndex={0}
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-inner text-white font-black group-hover:scale-105 transition-transform">
            <Store className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-black tracking-tight text-white leading-none">
                StockSmart
              </span>
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-emerald-500/40">
                BODEGA
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium mt-0.5">
              <span className="font-semibold text-emerald-400">Don Pepe</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 text-[11px] truncate">{currentDateFormatted}</span>
            </div>
          </div>
        </div>

        {/* Desktop: Active Module Context & Breadcrumb (>= MD) */}
        <div className="hidden md:flex items-center gap-3 select-none">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base lg:text-lg font-black tracking-tight text-white leading-none">
                {currentViewInfo.title}
              </h1>
              <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-500/30 uppercase">
                En Vivo
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium mt-0.5">
              {currentViewInfo.subtitle}
            </p>
          </div>
        </div>

        {/* Right Status Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          
          {/* Connection Toggle (En línea / Sin internet) */}
          <button
            onClick={toggleOnline}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold transition border select-none ${
              isOnline
                ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/80'
                : 'bg-amber-950/80 border-amber-500/60 text-amber-300 hover:bg-amber-900'
            }`}
            title="Toca para probar modo online/sin internet"
          >
            <span 
              className={`w-2.5 h-2.5 rounded-full ${
                isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`} 
            />
            <span className="text-xs">
              {isOnline ? 'En línea' : 'Sin internet'}
            </span>
            {pendingSyncCount > 0 && isOnline && (
              <span 
                onClick={(e) => { e.stopPropagation(); syncOfflineData(); }}
                className="bg-emerald-500 text-slate-950 px-1.5 py-0.2 rounded-full text-[10px] font-black flex items-center gap-0.5"
                title="Sincronizar ahora"
              >
                <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                {pendingSyncCount}
              </span>
            )}
          </button>

          {/* Shift Button */}
          <button
            onClick={toggleShift}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Cambiar turno de atención"
          >
            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Turno {shift}</span>
          </button>

          {/* Avatar Dropdown for Account, Plans, Settings & Tokens */}
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center gap-1.5 p-1 sm:px-2 sm:py-1 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
              aria-label="Menú de Don Pepe"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-extrabold flex items-center justify-center text-xs shadow-sm">
                DP
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div 
                className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl py-2 z-50 text-xs text-slate-200 divide-y divide-slate-800"
                onClick={() => setIsMenuOpen(false)}
              >
                <div className="px-3 py-2">
                  <p className="font-extrabold text-white text-sm">Don Pepe</p>
                  <p className="text-slate-400 text-[11px]">Dueño · Turno {shift}</p>
                  <p className="text-emerald-400 text-[10px] mt-0.5">Plan Bodega Pro (Activo)</p>
                </div>

                <div className="py-1">
                  <button
                    onClick={onOpenPlans}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 font-semibold text-amber-300"
                  >
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Planes y Suscripción</span>
                  </button>

                  <button
                    onClick={onOpenDesignTokens}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 font-semibold text-teal-300"
                  >
                    <Palette className="w-4 h-4 text-teal-400" />
                    <span>Guía de Diseño & Tokens</span>
                  </button>

                  <button
                    onClick={onOpenSettings}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 font-semibold text-slate-300"
                  >
                    <Settings className="w-4 h-4 text-slate-400" />
                    <span>Ajustes de la Bodega</span>
                  </button>
                </div>

                <div className="py-1">
                  <button
                    onClick={toggleShift}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center gap-2 text-slate-400"
                  >
                    <UserCheck className="w-4 h-4 text-slate-400" />
                    <span>Cambiar a Turno {shift === 'Mañana' ? 'Tarde' : 'Mañana'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
