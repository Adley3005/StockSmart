import React, { useState, useMemo, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product, ProductFilter, StockStatus, ExpiryStatus } from '../../types';
import { 
  Search, 
  Plus, 
  ClipboardCheck, 
  MoreVertical, 
  Truck, 
  ArrowUpDown, 
  AlertTriangle, 
  Clock, 
  Ban, 
  CheckCircle2, 
  Trash2, 
  Edit3, 
  PackageMinus,
  Sparkles,
  ChevronDown,
  X
} from 'lucide-react';
import { formatCurrency, getStockStatus, getExpiryDetails, formatDateShort } from '../../utils/helpers';

interface ProductsViewProps {
  onOpenReceiveStock: (product: Product) => void;
  onOpenStockCount: () => void;
  onOpenMermaModal: (product: Product) => void;
  onOpenEditModal: (product: Product) => void;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  onOpenReceiveStock,
  onOpenStockCount,
  onOpenMermaModal,
  onOpenEditModal
}) => {
  const { 
    products, 
    stockCounts, 
    expiryCounts, 
    deleteProduct,
    inventoryFilterInitial,
    setInventoryFilterInitial
  } = useBodega();

  // Active filter chip
  const [filter, setFilter] = useState<ProductFilter>(inventoryFilterInitial || 'todos');
  const [searchQuery, setSearchQuery] = useState('');

  // Sorting in desktop table
  const [sortField, setSortField] = useState<'name' | 'stock' | 'expiry' | 'price'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Active ⋮ menu open for product
  const [activeMenuProductId, setActiveMenuProductId] = useState<string | null>(null);

  // Sync initial filter if changed from dashboard
  useEffect(() => {
    if (inventoryFilterInitial) {
      setFilter(inventoryFilterInitial);
    }
  }, [inventoryFilterInitial]);

  // Handle sort toggle
  const handleSort = (field: 'name' | 'stock' | 'expiry' | 'price') => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Search
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode.includes(searchQuery) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      // Filter chips
      const stockStatus = getStockStatus(p);
      const expiryStatus = getExpiryDetails(p).status;

      if (filter === 'agotados') return stockStatus === 'Agotado';
      if (filter === 'bajos') return stockStatus === 'Bajo';
      if (filter === 'vencidos') return expiryStatus === 'Vencido';
      if (filter === 'por_vencer') return expiryStatus === 'Por vencer';
      return true; // 'todos'
    }).sort((a, b) => {
      const dir = sortDirection === 'asc' ? 1 : -1;
      if (sortField === 'name') return a.name.localeCompare(b.name) * dir;
      if (sortField === 'stock') return (a.stock - b.stock) * dir;
      if (sortField === 'price') return (a.price - b.price) * dir;
      if (sortField === 'expiry') return a.expiryDate.localeCompare(b.expiryDate) * dir;
      return 0;
    });
  }, [products, filter, searchQuery, sortField, sortDirection]);

  // Stock status badge component
  const renderStockBadge = (stockStatus: StockStatus) => {
    if (stockStatus === 'Agotado') {
      return (
        <span className="inline-flex items-center gap-1 bg-red-100 text-red-800 text-xs font-black px-2.5 py-0.5 rounded-full border border-red-300">
          <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
          Agotado
        </span>
      );
    }
    if (stockStatus === 'Bajo') {
      return (
        <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 text-xs font-black px-2.5 py-0.5 rounded-full border border-amber-300">
          <span className="w-2 h-2 rounded-full bg-amber-500" />
          Bajo
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full border border-emerald-300">
        <span className="w-2 h-2 rounded-full bg-emerald-500" />
        OK
      </span>
    );
  };

  // Expiry status badge component
  const renderExpiryBadge = (p: Product) => {
    const details = getExpiryDetails(p);

    if (details.status === 'Vencido') {
      return (
        <span className="inline-flex items-center gap-1 bg-rose-950 text-rose-200 text-xs font-black px-2.5 py-0.5 rounded-full border border-rose-800">
          <Ban className="w-3 h-3 text-rose-300 shrink-0" />
          {details.label}
        </span>
      );
    }
    if (details.status === 'Por vencer') {
      return (
        <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-950 text-xs font-black px-2.5 py-0.5 rounded-full border border-amber-300">
          <Clock className="w-3 h-3 text-amber-700 shrink-0" />
          {details.label}
        </span>
      );
    }
    // Vigente (lejano): sin indicador llamativo per requirement
    return (
      <span className="text-xs text-slate-500 font-medium">
        Lote: {formatDateShort(p.expiryDate)}
      </span>
    );
  };

  return (
    <div className="space-y-4 pb-12 select-none">
      
      {/* ============================================================ */}
      {/* 1. TOP CONTROLS & "CONTAR STOCK" GUIDED ACTION               */}
      {/* ============================================================ */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-sm border border-slate-200 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Filtrar por nombre, categoría o código..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-8 py-2.5 bg-slate-50 text-sm font-medium rounded-2xl border border-slate-200 focus:outline-none focus:border-emerald-600 focus:bg-white"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Action: Flujo Guiado "Contar stock" */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenStockCount}
            className="flex-1 md:flex-none min-h-[46px] px-4 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-sm transition flex items-center justify-center gap-2"
          >
            <ClipboardCheck className="w-4 h-4 text-emerald-400" />
            <span>Contar stock (Guiado)</span>
          </button>
        </div>

      </div>

      {/* ============================================================ */}
      {/* 2. CHIP FILTERS WITH EXACT REAL COUNTS (MATCHING HOY)        */}
      {/* ============================================================ */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
        
        {/* Todos (48) */}
        <button
          onClick={() => { setFilter('todos'); setInventoryFilterInitial('todos'); }}
          className={`min-h-[42px] px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
            filter === 'todos'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <span>Todos</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[11px] font-black ${
            filter === 'todos' ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-600'
          }`}>
            {stockCounts.total}
          </span>
        </button>

        {/* Agotados */}
        <button
          onClick={() => { setFilter('agotados'); setInventoryFilterInitial('agotados'); }}
          className={`min-h-[42px] px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
            filter === 'agotados'
              ? 'bg-red-600 text-white shadow-sm'
              : 'bg-red-50 text-red-800 hover:bg-red-100 border border-red-200'
          }`}
        >
          <span>Agotados</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[11px] font-black ${
            filter === 'agotados' ? 'bg-red-800 text-white' : 'bg-red-200 text-red-900'
          }`}>
            {stockCounts.agotados}
          </span>
        </button>

        {/* Bajos */}
        <button
          onClick={() => { setFilter('bajos'); setInventoryFilterInitial('bajos'); }}
          className={`min-h-[42px] px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
            filter === 'bajos'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
          }`}
        >
          <span>Bajos</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[11px] font-black ${
            filter === 'bajos' ? 'bg-amber-800 text-white' : 'bg-amber-200 text-amber-950'
          }`}>
            {stockCounts.bajos}
          </span>
        </button>

        {/* Vencidos */}
        <button
          onClick={() => { setFilter('vencidos'); setInventoryFilterInitial('vencidos'); }}
          className={`min-h-[42px] px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
            filter === 'vencidos'
              ? 'bg-rose-950 text-white shadow-sm border border-rose-900'
              : 'bg-rose-50 text-rose-900 hover:bg-rose-100 border border-rose-200'
          }`}
        >
          <span>Vencidos</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[11px] font-black ${
            filter === 'vencidos' ? 'bg-rose-800 text-white' : 'bg-rose-200 text-rose-950'
          }`}>
            {expiryCounts.vencidos}
          </span>
        </button>

        {/* Por vencer */}
        <button
          onClick={() => { setFilter('por_vencer'); setInventoryFilterInitial('por_vencer'); }}
          className={`min-h-[42px] px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
            filter === 'por_vencer'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
          }`}
        >
          <span>Por vencer</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[11px] font-black ${
            filter === 'por_vencer' ? 'bg-amber-950 text-white' : 'bg-amber-200 text-amber-900'
          }`}>
            {expiryCounts.porVencer}
          </span>
        </button>

      </div>

      {/* ============================================================ */}
      {/* 3. MOBILE: TARJETAS TÁCTILES (NO TABLA EN MÓVIL)             */}
      {/* ============================================================ */}
      <div className="md:hidden space-y-3">
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center text-slate-400 space-y-2">
            <p className="text-sm font-bold text-slate-700">No hay productos en esta categoría</p>
            <p className="text-xs">Prueba seleccionando otro filtro o limpiando la búsqueda.</p>
          </div>
        ) : (
          filteredProducts.map((prod) => {
            const stockStatus = getStockStatus(prod);
            const stockRatio = Math.min(100, Math.round((prod.stock / Math.max(1, prod.minStock)) * 100));

            return (
              <div
                key={prod.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3 relative"
              >
                {/* Product Name & Category */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-black text-slate-900 leading-tight">
                      {prod.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 font-medium">
                      <span>{prod.category}</span>
                      <span>•</span>
                      <span className="font-semibold text-slate-700">Unidad: {prod.unit}</span>
                    </div>
                  </div>

                  {/* Menu ⋮ */}
                  <div className="relative">
                    <button
                      onClick={() => setActiveMenuProductId(activeMenuProductId === prod.id ? null : prod.id)}
                      className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center"
                      aria-label="Más acciones"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuProductId === prod.id && (
                      <div 
                        className="absolute right-0 mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-30 text-xs"
                        onClick={() => setActiveMenuProductId(null)}
                      >
                        <button
                          onClick={() => onOpenEditModal(prod)}
                          className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-semibold"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Editar producto</span>
                        </button>
                        <button
                          onClick={() => onOpenMermaModal(prod)}
                          className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-amber-700 font-semibold"
                        >
                          <PackageMinus className="w-3.5 h-3.5" />
                          <span>Reportar merma</span>
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`¿Seguro que deseas eliminar "${prod.name}" del catálogo?`)) {
                              deleteProduct(prod.id);
                            }
                          }}
                          className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-rose-600 font-semibold"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Eliminar</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Stock actual / mínimo con barra visual */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">
                      Stock: <strong className="text-slate-900 font-mono">{prod.stock}</strong> / mín. {prod.minStock} {prod.unit}s
                    </span>
                    <span className="font-mono text-slate-900 font-black">
                      {formatCurrency(prod.price)}
                    </span>
                  </div>

                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        stockStatus === 'Agotado'
                          ? 'bg-red-600'
                          : stockStatus === 'Bajo'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${stockRatio}%` }}
                    />
                  </div>
                </div>

                {/* Chips de estado: Stock y Vencimiento */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {renderStockBadge(stockStatus)}
                  {renderExpiryBadge(prod)}
                </div>

                {/* Acción Principal: Recibir Mercadería */}
                <div className="pt-2 border-t border-slate-100">
                  <button
                    onClick={() => onOpenReceiveStock(prod)}
                    className="w-full min-h-[44px] bg-slate-900 hover:bg-slate-800 active:scale-98 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Truck className="w-4 h-4 text-emerald-400" />
                    <span>Recibir mercadería (+ Reponer)</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ============================================================ */}
      {/* 4. DESKTOP: TABLA ORDENABLE CON COLUMNAS SEPARADAS           */}
      {/* ============================================================ */}
      <div className="hidden md:block bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                
                {/* Producto */}
                <th 
                  onClick={() => handleSort('name')}
                  className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Producto & Unidad</span>
                    <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                </th>

                {/* Categoría */}
                <th className="py-3.5 px-3">Categoría</th>

                {/* Stock actual / mín */}
                <th 
                  onClick={() => handleSort('stock')}
                  className="py-3.5 px-3 cursor-pointer hover:bg-slate-100 transition text-center"
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Stock / Mínimo</span>
                    <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                </th>

                {/* Eje Stock */}
                <th className="py-3.5 px-3 text-center">Estado de Stock</th>

                {/* Eje Vencimiento */}
                <th 
                  onClick={() => handleSort('expiry')}
                  className="py-3.5 px-3 cursor-pointer hover:bg-slate-100 transition"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Vencimiento</span>
                    <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                </th>

                {/* Precio */}
                <th 
                  onClick={() => handleSort('price')}
                  className="py-3.5 px-3 cursor-pointer hover:bg-slate-100 transition text-right"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Precio Venta</span>
                    <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                </th>

                {/* Acciones */}
                <th className="py-3.5 px-4 text-right">Acción Principal</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((prod) => {
                const stockStatus = getStockStatus(prod);

                return (
                  <tr key={prod.id} className="hover:bg-slate-50/80 transition">
                    
                    {/* Producto */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{prod.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        SKU: {prod.barcode} · Unidad: <span className="font-semibold text-slate-700">{prod.unit}</span>
                      </div>
                    </td>

                    {/* Categoría */}
                    <td className="py-3 px-3">
                      <span className="bg-slate-100 text-slate-700 text-xs px-2 py-0.5 rounded-lg font-medium">
                        {prod.category}
                      </span>
                    </td>

                    {/* Stock */}
                    <td className="py-3 px-3 text-center font-mono">
                      <span className={`font-black ${
                        stockStatus === 'Agotado' ? 'text-red-700' : stockStatus === 'Bajo' ? 'text-amber-700' : 'text-slate-900'
                      }`}>
                        {prod.stock}
                      </span>
                      <span className="text-slate-400 text-xs"> / {prod.minStock} {prod.unit}s</span>
                    </td>

                    {/* Chip de Stock */}
                    <td className="py-3 px-3 text-center">
                      {renderStockBadge(stockStatus)}
                    </td>

                    {/* Chip de Vencimiento */}
                    <td className="py-3 px-3">
                      {renderExpiryBadge(prod)}
                    </td>

                    {/* Precio */}
                    <td className="py-3 px-3 text-right font-mono font-black text-slate-900">
                      {formatCurrency(prod.price)}
                    </td>

                    {/* Acciones */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenReceiveStock(prod)}
                          className="min-h-[38px] px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                          title="Recibir mercadería del proveedor"
                        >
                          <Truck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Recibir</span>
                        </button>

                        <div className="relative">
                          <button
                            onClick={() => setActiveMenuProductId(activeMenuProductId === prod.id ? null : prod.id)}
                            className="w-8 h-8 rounded-lg hover:bg-slate-200 text-slate-600 flex items-center justify-center"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>

                          {activeMenuProductId === prod.id && (
                            <div 
                              className="absolute right-0 mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-30 text-xs text-left"
                              onClick={() => setActiveMenuProductId(null)}
                            >
                              <button
                                onClick={() => onOpenEditModal(prod)}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-semibold"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>Editar</span>
                              </button>
                              <button
                                onClick={() => onOpenMermaModal(prod)}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-amber-700 font-semibold"
                              >
                                <PackageMinus className="w-3.5 h-3.5" />
                                <span>Reportar merma</span>
                              </button>
                              <button
                                onClick={() => {
                                  if (window.confirm(`¿Eliminar "${prod.name}"?`)) {
                                    deleteProduct(prod.id);
                                  }
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2 text-rose-600 font-semibold"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Eliminar</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
