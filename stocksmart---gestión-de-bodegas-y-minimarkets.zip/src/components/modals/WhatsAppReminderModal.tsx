import React, { useState } from 'react';
import { CustomerFiado } from '../../types';
import { useBodega } from '../../context/BodegaContext';
import { Send, Copy, Check, X, MessageCircle } from 'lucide-react';
import { formatCurrency } from '../../utils/helpers';

interface WhatsAppReminderModalProps {
  customer: CustomerFiado | null;
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppReminderModal: React.FC<WhatsAppReminderModalProps> = ({
  customer,
  isOpen,
  onClose
}) => {
  const { showToast } = useBodega();
  const [copied, setCopied] = useState(false);

  if (!isOpen || !customer) return null;

  // Friendly Peruvian bodega reminder message
  const reminderMessage = `Hola ${customer.name}, ¿cómo está? Le saluda Don Pepe del Minimarket. Le escribo cordialmente para compartirle su saldo en el cuaderno de fiados al día de hoy: *${formatCurrency(customer.balance)}*. Si puede pasar a dejar un abono cuando le sea posible, se lo agradeceré mucho vecina(o). ¡Que tenga un bendecido día! 😊🛒`;

  const handleCopy = () => {
    navigator.clipboard?.writeText(reminderMessage);
    setCopied(true);
    showToast(`Mensaje copiado para el WhatsApp de ${customer.name}`, 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleOpenWhatsApp = () => {
    const encoded = encodeURIComponent(reminderMessage);
    const url = `https://wa.me/51${customer.phone}?text=${encoded}`;
    window.open(url, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none">
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Aviso por WhatsApp
              </h3>
              <p className="text-[11px] text-slate-500">Tono cordial de confianza de barrio</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customer & Debt info */}
        <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs flex justify-between items-center">
          <div>
            <p className="font-extrabold text-slate-900">{customer.name}</p>
            <p className="text-[11px] text-slate-500 font-mono">Teléfono: +51 {customer.phone}</p>
          </div>
          <span className="text-base font-black font-mono text-slate-900">
            {formatCurrency(customer.balance)}
          </span>
        </div>

        {/* Message preview box */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-700">
            Vista previa del mensaje:
          </label>
          <div className="bg-emerald-50/60 p-3.5 rounded-2xl border border-emerald-200 text-xs text-slate-800 leading-relaxed font-sans">
            {reminderMessage}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleCopy}
            className="w-full min-h-[44px] bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow transition"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? '¡MENSAJE COPIADO!' : 'COPIAR TEXTO PARA WHATSAPP'}</span>
          </button>

          <button
            onClick={handleOpenWhatsApp}
            className="w-full min-h-[44px] bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition"
          >
            <Send className="w-4 h-4 text-emerald-400" />
            <span>Abrir chat de WhatsApp</span>
          </button>

          <button
            onClick={onClose}
            className="w-full py-2 text-slate-500 hover:text-slate-700 font-bold text-xs"
          >
            Cancelar
          </button>
        </div>

      </div>
    </div>
  );
};
