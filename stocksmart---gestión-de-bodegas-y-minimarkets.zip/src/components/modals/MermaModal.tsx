import React, { useState, useEffect } from 'react';
import { useBodega } from '../../context/BodegaContext';
import { Product } from '../../types';
import { PackageMinus, X } from 'lucide-react';
import { formatUnitPlural } from '../../utils/helpers';

interface MermaModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const MermaModal: React.FC<MermaModalProps> = ({ product, isOpen, onClose }) => {
  const { reportMerma } = useBodega();
  const [quantity, setQuantity] = useState<number>(1);
  const [reason, setReason] = useState<string>('Vencido en góndola');

  useEffect(() => {
    if (product) {
      setQuantity(1);
      setReason('Vencido en góndola');
    }
  }, [product]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const handleConfirm = () => {
    if (quantity > 0) {
      reportMerma(product.id, quantity, reason);
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 border border-slate-200 animate-slide-up">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <PackageMinus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                Reportar Merma / Baja
              </h3>
              <p className="text-[11px] text-slate-500">Descuenta del stock por daño o vencimiento</p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-600" aria-label="Cerrar">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product details */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs">
          <p className="font-extrabold text-slate-900 text-sm">{product.name}</p>
          <p className="text-slate-600 mt-1">
            Stock actual: <strong className="font-mono text-slate-900">{formatUnitPlural(product.stock, product.unit)}</strong>
          </p>
        </div>

        {/* Quantity */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-700">
            Cantidad de {product.unit}s a dar de baja:
          </label>
          <input
            type="number"
            min="1"
            max={Math.max(1, product.stock)}
            value={quantity}
            onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
            className="w-full p-3 text-center font-mono font-black text-lg border border-slate-300 rounded-xl focus:border-emerald-600 outline-none"
          />
        </div>

        {/* Reason */}
        <div className="space-y-1">
          <label className="block text-xs font-bold text-slate-700">
            Motivo de la merma:
          </label>
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full p-2.5 text-xs font-bold bg-white border border-slate-300 rounded-xl outline-none"
          >
            <option value="Vencido en góndola">Vencido en góndola</option>
            <option value="Empaque roto o derrame">Empaque roto o derrame</option>
            <option value="Lata abollada / golpeada">Lata abollada / golpeada</option>
            <option value="Consumo del bodeguero">Consumo del bodeguero</option>
            <option value="Devolución a proveedor rechazada">Devolución a proveedor rechazada</option>
          </select>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={handleConfirm}
            className="min-h-[46px] bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1 shadow cursor-pointer active:scale-95"
          >
            Confirmar Baja
          </button>
          <button
            onClick={onClose}
            className="min-h-[46px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
          >
            Cancelar
          </button>
        </div>

      </div>
    </div>
  );
};
