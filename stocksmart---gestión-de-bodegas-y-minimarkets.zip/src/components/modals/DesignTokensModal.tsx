import React from 'react';
import { Palette, X, Check, ShieldCheck, Type, LayoutGrid, Layers } from 'lucide-react';

interface DesignTokensModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DesignTokensModal: React.FC<DesignTokensModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl flex flex-col max-h-[92vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Sistema de Diseño & Hoja de Tokens (StockSmart)
              </h2>
              <p className="text-xs text-slate-500">
                Diseñado para bodegueros en Lima: luz intensa, uso a una mano y accesibilidad WCAG AA
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="my-4 overflow-y-auto flex-1 space-y-6 pr-1 text-xs">
          
          {/* SECTION 1: TOKENS DE COLOR SEMÁNTICOS */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                1. Tokens de Color Semánticos (Contraste WCAG 2.1 AA)
              </h3>
            </div>
            <p className="text-slate-600">
              Cada color tiene un significado único. Modo claro optimizado para la alta iluminación de la bodega.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {/* Brand */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-[10px]">
                  #16A34A
                </div>
                <p className="font-extrabold text-slate-900">brand / primary</p>
                <p className="text-[11px] text-slate-500">Botones de cobro, identidad de bodega, saldo al día.</p>
              </div>

              {/* Success */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-emerald-500 flex items-center justify-center text-white font-bold text-[10px]">
                  #10B981
                </div>
                <p className="font-extrabold text-slate-900">success (OK)</p>
                <p className="text-[11px] text-slate-500">Stock OK (&ge; mínimo), fiado &lt; 70%, sincronizado.</p>
              </div>

              {/* Warning */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 font-bold text-[10px]">
                  #F59E0B
                </div>
                <p className="font-extrabold text-slate-900">warning (Alerta)</p>
                <p className="text-[11px] text-slate-500">Stock Bajo, por vencer (&le; 7d), fiado 70-99%, offline.</p>
              </div>

              {/* Danger */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-[10px]">
                  #DC2626
                </div>
                <p className="font-extrabold text-slate-900">danger (Agotado)</p>
                <p className="text-[11px] text-slate-500">Stock Agotado (0 uds), deuda que superó tope.</p>
              </div>

              {/* Danger Strong */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-rose-950 flex items-center justify-center text-rose-200 font-bold text-[10px]">
                  #4C0519
                </div>
                <p className="font-extrabold text-slate-900">danger-strong (Vencido)</p>
                <p className="text-[11px] text-slate-500">Vencido (fecha pasada). Máxima urgencia sanitaria.</p>
              </div>

              {/* Neutral */}
              <div className="p-3 rounded-2xl border border-slate-200 bg-slate-50 space-y-1">
                <div className="h-7 w-full rounded-lg bg-slate-900 flex items-center justify-center text-white font-bold text-[10px]">
                  #0F172A
                </div>
                <p className="font-extrabold text-slate-900">neutral / dark</p>
                <p className="text-[11px] text-slate-500">Saldos normales fiado, encabezado, texto de alta legibilidad.</p>
              </div>
            </div>
          </div>

          {/* SECTION 2: TIPOGRAFÍA Y ACCESIBILIDAD */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                2. Jerarquía Tipográfica y Criterio de Legibilidad
              </h3>
            </div>
            
            <div className="bg-slate-50 rounded-2xl p-3.5 space-y-2 border border-slate-200">
              <div className="flex items-baseline justify-between border-b border-slate-200 pb-1.5">
                <span className="text-sm font-black text-slate-900">Cuerpo base: 16px</span>
                <span className="text-slate-500">Mínimo exigido para vista cansada sin esfuerzo</span>
              </div>
              <div className="flex items-baseline justify-between border-b border-slate-200 pb-1.5">
                <span className="text-xs font-bold text-slate-800">Etiquetas: 13px - 14px</span>
                <span className="text-slate-500">Nunca mayúsculas grises diminutas ilegibles</span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="font-mono font-black text-base text-slate-900">Monospace: JetBrains Mono</span>
                <span className="text-slate-500">Para precios S/ y números de inventario sin error</span>
              </div>
            </div>
          </div>

          {/* SECTION 3: ESPACIADO Y TOUCH TARGETS */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2">
              <LayoutGrid className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                3. Escala de Espaciado y Área Táctil (&ge; 48px)
              </h3>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2.5 bg-slate-100 rounded-xl">
                <p className="font-black text-slate-900">4px / 8px</p>
                <p className="text-[11px] text-slate-500">Microespaciado</p>
              </div>
              <div className="p-2.5 bg-slate-100 rounded-xl">
                <p className="font-black text-slate-900">12px / 16px</p>
                <p className="text-[11px] text-slate-500">Padding de tarjeta</p>
              </div>
              <div className="p-2.5 bg-slate-100 rounded-xl">
                <p className="font-black text-slate-900">24px / 32px</p>
                <p className="text-[11px] text-slate-500">Separación de bloques</p>
              </div>
              <div className="p-2.5 bg-emerald-100 text-emerald-950 rounded-xl border border-emerald-300">
                <p className="font-black">&ge; 48px</p>
                <p className="text-[11px]">Área táctil mínima</p>
              </div>
            </div>
          </div>

          {/* SECTION 4: COMPONENTES VIVOS */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-600" />
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                4. Catálogo de Componentes Vivos
              </h3>
            </div>

            {/* Chips de estado */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <p className="font-bold text-slate-700">Chips de Estado (Stock y Vencimiento independientes):</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-300">
                  ● Stock OK
                </span>
                <span className="bg-amber-100 text-amber-900 text-xs font-black px-2.5 py-1 rounded-full border border-amber-300">
                  ● Stock Bajo
                </span>
                <span className="bg-red-100 text-red-900 text-xs font-black px-2.5 py-1 rounded-full border border-red-300">
                  ● Agotado (0 uds)
                </span>
                <span className="bg-rose-950 text-rose-200 text-xs font-black px-2.5 py-1 rounded-full border border-rose-800">
                  ⊘ Vencido hace 18 días
                </span>
                <span className="bg-amber-100 text-amber-950 text-xs font-black px-2.5 py-1 rounded-full border border-amber-300">
                  ⏱ Vence en 3 días
                </span>
              </div>
            </div>

            {/* Umbrales de fiados */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <p className="font-bold text-slate-700">Umbrales de Cuaderno de Fiados:</p>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-emerald-700">&lt; 70% del tope (Bajo riesgo)</span>
                  <div className="w-32 bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[45%]" />
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-amber-700">70% – 99% del tope (Atención)</span>
                  <div className="w-32 bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full w-[85%]" />
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-red-700">&ge; 100% del tope (Bloqueo / Superado)</span>
                  <div className="w-32 bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-red-600 h-full w-[100%]" />
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="min-h-[44px] px-6 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl"
          >
            Entendido
          </button>
        </div>

      </div>
    </div>
  );
};
